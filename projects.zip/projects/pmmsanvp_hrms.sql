-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 30, 2019 at 12:04 PM
-- Server version: 5.6.41-84.1-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmmsanvp_hrms`
--

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asset_type_id` int(10) UNSIGNED NOT NULL,
  `master_asset_id` int(10) UNSIGNED DEFAULT NULL,
  `asset_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `s_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_bill_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_replacement_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_warranty` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warranty_end_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_id` int(11) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `asset_code`, `asset_type_id`, `master_asset_id`, `asset_id`, `name`, `s_no`, `purchase_bill_date`, `repair_replacement_date`, `is_warranty`, `warranty_end_date`, `system_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'MN001', 1, NULL, 1, 'Monitor', 'M001', NULL, NULL, '0', NULL, NULL, 'free', '2018-12-14 10:56:26', '2018-12-14 10:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `asset_assocs`
--

CREATE TABLE `asset_assocs` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_type_id` int(10) UNSIGNED NOT NULL,
  `master_asset_id` int(10) UNSIGNED NOT NULL,
  `asset_assoc_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_assocs`
--

INSERT INTO `asset_assocs` (`id`, `asset_type_id`, `master_asset_id`, `asset_assoc_code`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'MN', 'Monitor', NULL, NULL),
(2, 1, 3, 'KB', 'Keyboard', NULL, NULL),
(3, 1, 3, 'MN', 'Mouse', NULL, NULL),
(4, 1, 3, 'CB', 'Cabinet', NULL, NULL),
(5, 1, 3, 'MB', 'Motherboard', NULL, NULL),
(6, 1, 3, 'RM', 'RAM', NULL, NULL),
(7, 1, 3, 'PU', 'Processer', NULL, NULL),
(8, 1, 3, 'UP', 'UPS/Battery', NULL, NULL),
(9, 1, 3, 'SM', 'SMPS', NULL, NULL),
(10, 1, 3, 'HD', 'HDD', NULL, NULL),
(11, 1, 3, 'DT', 'Desktop', NULL, NULL),
(12, 1, 4, 'LP', 'Laptop', NULL, NULL),
(13, 1, 5, 'AM', 'Mac Mini', NULL, NULL),
(14, 1, 6, 'IM', 'iMac', NULL, NULL),
(15, 1, 11, 'NS', 'Network Switch', NULL, NULL),
(16, 1, 11, 'RT', 'Router', NULL, NULL),
(17, 1, 11, 'RP', 'Repeater', NULL, NULL),
(18, 1, 10, 'HDD', 'HDD', NULL, NULL),
(19, 1, 10, 'PD', 'PenDrive', NULL, NULL),
(20, 1, 7, 'DV', 'DVR', NULL, NULL),
(21, 1, 7, 'CM', 'Camera', NULL, NULL),
(22, 1, 7, 'WC', 'WebCam', NULL, NULL),
(23, 1, 12, 'PR', 'Printer', NULL, NULL),
(24, 2, 13, 'CH', 'Chair', NULL, NULL),
(25, 2, 13, 'DS', 'Desk', NULL, NULL),
(26, 2, 13, 'FN', 'Fan', NULL, NULL),
(27, 2, 13, 'AC', 'AC', NULL, NULL),
(28, 2, 13, 'AL', 'Almirah', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `asset_types`
--

CREATE TABLE `asset_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_types`
--

INSERT INTO `asset_types` (`id`, `type`, `created_at`, `updated_at`) VALUES
(1, 'IT Asset', NULL, NULL),
(2, 'Infra Asset', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `attendance_data`
--

CREATE TABLE `attendance_data` (
  `id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `employee_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `attendance_data`
--

INSERT INTO `attendance_data` (`id`, `attendance_date`, `status`, `employee_id`, `created_at`, `updated_at`) VALUES
(1, '2018-06-27', 'HD', 'EMP0067', '2018-06-27 12:48:28', '2018-06-27 12:54:32'),
(2, '2018-06-27', 'P', 'EMP0064', '2018-06-27 12:51:03', '2018-06-27 12:51:03'),
(3, '2018-06-27', 'P', 'EMP0059', '2018-06-27 12:54:32', '2018-06-27 12:54:32'),
(4, '2018-06-27', 'P', 'EMP0061', '2018-06-27 12:54:32', '2018-06-27 12:54:32'),
(5, '2018-06-27', 'P', 'EMP0063', '2018-06-27 12:54:32', '2018-06-27 12:54:32'),
(6, '2018-06-27', 'P', 'EMP0065', '2018-06-27 12:54:32', '2018-06-27 12:54:32'),
(7, '2018-06-27', 'P', 'EMP0066', '2018-06-27 12:54:32', '2018-06-27 12:54:32'),
(8, '2018-07-10', 'P', 'EMP0067', '2018-07-10 11:14:23', '2018-07-10 11:14:23'),
(9, '2018-07-19', 'P', 'EMP0069', '2018-07-19 09:26:40', '2018-07-19 09:26:40'),
(10, '2018-07-19', 'P', 'EMP0071', '2018-07-19 09:27:01', '2018-07-19 09:27:01'),
(11, '2018-07-19', 'P', 'EMP0074', '2018-07-19 09:59:26', '2018-07-19 09:59:26'),
(12, '2018-07-20', 'P', 'EMP0076', '2018-07-20 09:30:30', '2018-07-20 09:30:30'),
(13, '2018-07-20', 'P', 'EMP0074', '2018-07-20 09:39:50', '2018-07-20 09:39:50'),
(14, '2018-07-21', 'P', 'EMP0075', '2018-07-21 09:30:38', '2018-07-21 09:30:38'),
(15, '2018-07-21', 'P', 'EMP0076', '2018-07-21 09:35:30', '2018-07-21 09:35:30'),
(16, '2018-07-21', 'P', 'EMP0074', '2018-07-21 10:11:31', '2018-07-21 10:11:31'),
(17, '2018-07-23', 'P', 'EMP0074', '2018-07-23 09:35:10', '2018-07-23 09:35:10'),
(18, '2018-07-24', 'P', 'EMP0074', '2018-07-24 09:47:35', '2018-07-24 09:47:35'),
(19, '2018-07-25', 'P', 'EMP0074', '2018-07-25 09:23:10', '2018-07-25 09:23:10'),
(20, '2018-07-26', 'P', 'EMP0076', '2018-07-26 09:35:38', '2018-07-26 09:35:38'),
(21, '2018-07-27', 'P', 'EMP0074', '2018-07-27 09:56:45', '2018-07-27 09:56:45'),
(22, '2018-07-28', 'P', 'EMP0074', '2018-07-28 09:43:24', '2018-07-28 09:43:24'),
(23, '2018-08-02', 'P', 'EMP0074', '2018-08-02 10:51:18', '2018-08-02 10:51:18'),
(24, '2018-08-10', 'P', 'EMP0074', '2018-08-10 11:19:00', '2018-08-10 11:19:00'),
(25, '2018-08-12', 'P', 'EMP0074', '2018-08-12 10:41:43', '2018-08-12 10:41:43'),
(26, '2018-08-16', 'P', 'EMP0074', '2018-08-16 10:51:17', '2018-08-16 10:51:17'),
(27, '2018-08-23', 'P', 'EMP0074', '2018-08-23 10:57:06', '2018-08-23 10:57:06'),
(28, '2018-08-27', 'P', 'EMP0074', '2018-08-27 09:41:35', '2018-08-27 09:41:35'),
(29, '2018-08-31', 'P', 'EMP0074', '2018-08-31 09:40:34', '2018-08-31 09:40:34'),
(30, '2018-12-14', 'P', 'EMP0068', '2018-12-14 10:47:49', '2018-12-14 10:47:49'),
(31, '2018-12-14', 'P', 'EMP0074', '2018-12-14 10:54:24', '2018-12-14 10:54:24'),
(32, '2019-01-03', 'P', 'EMP0068', '2019-01-03 13:59:33', '2019-01-03 13:59:33'),
(33, '2019-02-09', 'P', 'EMP0068', '2019-02-09 09:51:22', '2019-02-09 09:51:22'),
(34, '2019-02-09', 'P', 'EMP0072', '2019-02-09 10:22:04', '2019-02-09 10:22:04'),
(35, '2019-02-09', 'P', 'EMP0075', '2019-02-09 10:22:46', '2019-02-09 10:22:46'),
(36, '2019-02-09', 'P', 'EMP0074', '2019-02-09 10:24:06', '2019-02-09 10:24:06'),
(37, '2019-02-09', 'P', 'EMP0069', '2019-02-09 10:25:44', '2019-02-09 10:25:44'),
(38, '2019-02-09', 'P', 'EMP0079', '2019-02-09 10:31:21', '2019-02-09 10:31:21'),
(39, '2019-02-09', 'P', 'EMP0077', '2019-02-09 10:39:30', '2019-02-09 10:39:30'),
(40, '2019-02-09', 'P', 'EMP0071', '2019-02-09 10:43:46', '2019-02-09 10:43:46'),
(41, '2019-02-11', 'P', 'EMP0071', '2019-02-11 10:15:43', '2019-02-11 10:15:43'),
(42, '2019-02-11', 'P', 'EMP0069', '2019-02-11 10:23:53', '2019-02-11 10:23:53'),
(43, '2019-02-12', 'P', 'EMP0074', '2019-02-12 09:56:37', '2019-02-12 09:56:37'),
(44, '2019-02-12', 'P', 'EMP0077', '2019-02-12 09:59:10', '2019-02-12 09:59:10'),
(45, '2019-02-15', 'P', 'EMP0074', '2019-02-15 12:13:35', '2019-02-15 12:13:35'),
(46, '2019-02-19', 'P', 'EMP0072', '2019-02-19 11:46:39', '2019-02-19 11:46:39'),
(47, '2019-02-20', 'P', 'EMP0074', '2019-02-20 10:12:11', '2019-02-20 10:12:11'),
(48, '2019-02-25', 'P', 'EMP0072', '2019-02-25 10:23:04', '2019-02-25 10:23:04'),
(49, '2019-02-26', 'P', 'EMP0074', '2019-02-26 10:06:17', '2019-02-26 10:06:17'),
(50, '2019-02-26', 'P', 'EMP0072', '2019-02-26 11:28:42', '2019-02-26 11:28:42'),
(51, '2019-02-27', 'P', 'EMP0072', '2019-02-27 11:52:13', '2019-02-27 11:52:13'),
(52, '2019-02-28', 'P', 'EMP0072', '2019-02-28 09:51:37', '2019-02-28 09:51:37'),
(53, '2019-02-28', 'P', 'EMP0080', '2019-02-28 13:16:11', '2019-02-28 13:16:11'),
(54, '2019-03-01', 'P', 'EMP0080', '2019-03-01 13:12:35', '2019-03-01 13:12:35'),
(55, '2019-03-04', 'P', 'EMP0072', '2019-03-04 09:30:13', '2019-03-04 10:02:06'),
(56, '2019-03-04', 'P', 'EMP0077', '2019-03-04 09:50:12', '2019-03-04 10:02:06'),
(57, '2019-03-04', 'P', 'EMP0068', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(58, '2019-03-04', 'P', 'EMP0069', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(59, '2019-03-04', 'P', 'EMP0070', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(60, '2019-03-04', 'P', 'EMP0071', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(61, '2019-03-04', 'P', 'EMP0073', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(62, '2019-03-04', 'P', 'EMP0074', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(63, '2019-03-04', 'P', 'EMP0075', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(64, '2019-03-04', 'P', 'EMP0076', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(65, '2019-03-04', 'P', 'EMP0079', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(66, '2019-03-04', 'P', 'EMP0080', '2019-03-04 10:02:06', '2019-03-04 10:02:06'),
(67, '2019-03-05', 'P', 'EMP0072', '2019-03-05 09:19:45', '2019-03-05 09:19:45'),
(68, '2019-03-09', 'P', 'EMP0072', '2019-03-09 09:19:51', '2019-03-09 09:19:51'),
(69, '2019-03-11', 'P', 'EMP0072', '2019-03-11 09:34:14', '2019-03-11 09:34:14'),
(70, '2019-03-12', 'P', 'EMP0072', '2019-03-12 09:30:30', '2019-03-12 09:30:30'),
(71, '2019-03-14', 'P', 'EMP0072', '2019-03-14 09:11:09', '2019-03-14 09:11:09'),
(72, '2019-03-16', 'P', 'EMP0072', '2019-03-16 09:53:26', '2019-03-16 09:53:26'),
(73, '2019-03-16', 'P', 'EMP0081', '2019-03-16 11:17:20', '2019-03-16 11:17:20'),
(74, '2019-03-16', 'P', 'EMP0074', '2019-03-16 11:17:44', '2019-03-16 11:17:44'),
(75, '2019-03-18', 'P', 'EMP0072', '2019-03-18 09:38:12', '2019-03-18 09:38:12'),
(76, '2019-03-19', 'P', 'EMP0072', '2019-03-19 10:20:35', '2019-03-19 10:20:35'),
(77, '2019-03-23', 'P', 'EMP0074', '2019-03-23 10:20:55', '2019-03-23 10:20:55'),
(78, '2019-03-26', 'P', 'EMP0068', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(79, '2019-03-26', 'P', 'EMP0069', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(80, '2019-03-26', 'P', 'EMP0070', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(81, '2019-03-26', 'P', 'EMP0071', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(82, '2019-03-26', 'P', 'EMP0072', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(83, '2019-03-26', 'P', 'EMP0073', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(84, '2019-03-26', 'P', 'EMP0074', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(85, '2019-03-26', 'P', 'EMP0075', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(86, '2019-03-26', 'P', 'EMP0076', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(87, '2019-03-26', 'P', 'EMP0077', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(88, '2019-03-26', 'P', 'EMP0079', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(89, '2019-03-26', 'P', 'EMP0080', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(90, '2019-03-26', 'P', 'EMP0081', '2019-03-27 18:07:21', '2019-03-27 18:07:21'),
(91, '2019-03-27', 'AB', 'EMP0068', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(92, '2019-03-27', 'P', 'EMP0069', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(93, '2019-03-27', 'AB', 'EMP0070', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(94, '2019-03-27', 'P', 'EMP0071', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(95, '2019-03-27', 'AB', 'EMP0072', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(96, '2019-03-27', 'AB', 'EMP0073', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(97, '2019-03-27', 'P', 'EMP0074', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(98, '2019-03-27', 'P', 'EMP0075', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(99, '2019-03-27', 'P', 'EMP0076', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(100, '2019-03-27', 'P', 'EMP0077', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(101, '2019-03-27', 'P', 'EMP0079', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(102, '2019-03-27', 'P', 'EMP0080', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(103, '2019-03-27', 'P', 'EMP0081', '2019-03-27 18:07:57', '2019-03-27 18:07:57'),
(104, '2019-03-28', 'P', 'EMP0072', '2019-03-28 09:11:29', '2019-03-28 09:11:29'),
(105, '2019-03-28', 'P', 'EMP0074', '2019-03-28 10:48:31', '2019-03-28 10:48:31'),
(106, '2019-03-29', 'P', 'EMP0072', '2019-03-29 09:13:20', '2019-03-29 09:13:20'),
(107, '2019-03-30', 'P', 'EMP0072', '2019-03-30 10:01:56', '2019-03-30 10:01:56');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_filenames`
--

CREATE TABLE `attendance_filenames` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendance_managers`
--

CREATE TABLE `attendance_managers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `day` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `in_time` time NOT NULL,
  `out_time` time NOT NULL,
  `hours_worked` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `difference` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `leave_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dayType`
--

CREATE TABLE `dayType` (
  `id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `short_name` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dayType`
--

INSERT INTO `dayType` (`id`, `name`, `short_name`, `description`) VALUES
(1, 'Present', 'P', 'present'),
(2, 'Absent ', 'AB', 'absent '),
(3, 'Un inform', 'UI', 'Un inform'),
(4, 'Half Day', 'HD', 'half Day'),
(5, 'Over Time', 'OT', 'Over Time');

-- --------------------------------------------------------

--
-- Table structure for table `employee_cb_appraisal_details`
--

CREATE TABLE `employee_cb_appraisal_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `appraisal_term` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stay_bonus` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appraisal_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appraisal_comment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_cb_appraisal_details`
--

INSERT INTO `employee_cb_appraisal_details` (`id`, `user_id`, `appraisal_term`, `designation`, `salary`, `stay_bonus`, `appraisal_status`, `appraisal_comment`, `created_at`, `updated_at`) VALUES
(8, 68, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 14:30:12', '2018-07-18 14:32:45'),
(9, 69, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 14:40:57', '2018-07-18 14:42:41'),
(10, 70, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 14:55:22', '2018-07-18 14:55:56'),
(11, 71, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 15:04:52', '2018-07-18 15:05:45'),
(12, 72, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 15:11:19', '2018-07-18 15:12:42'),
(13, 73, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 15:17:36', '2018-07-18 15:19:15'),
(14, 74, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 15:25:20', '2018-07-18 15:28:05'),
(15, 75, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 15:31:46', '2018-07-18 15:32:19'),
(16, 76, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 15:35:36', '2018-07-18 15:36:07'),
(17, 77, 'first', NULL, NULL, NULL, 'not_done', NULL, '2018-07-18 15:42:50', '2018-07-18 15:43:49'),
(19, 79, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-09 10:30:52', '2019-02-09 10:30:52'),
(20, 80, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-28 13:15:49', '2019-02-28 13:15:49'),
(21, 81, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-15 17:57:26', '2019-03-15 17:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_cb_profiles`
--

CREATE TABLE `employee_cb_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_pic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joined_as` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joining_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stay_bonus` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appraisal_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notice_period` int(11) DEFAULT NULL,
  `epf` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `esi` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avail_leaves` int(11) NOT NULL DEFAULT '0',
  `leaves_taken` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_cb_profiles`
--

INSERT INTO `employee_cb_profiles` (`id`, `user_id`, `employee_id`, `employee_pic`, `designation`, `joined_as`, `joining_date`, `status`, `salary`, `stay_bonus`, `appraisal_date`, `notice_period`, `epf`, `esi`, `avail_leaves`, `leaves_taken`, `created_at`, `updated_at`) VALUES
(8, 68, 'EMP0068', 'http://hrms.pmmsapp.com/images/employees/1531904565.jpg', 'IT Head', 'Web Developer', '04/12/2012', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 14:30:12', '2018-07-18 14:34:27'),
(9, 69, 'EMP0069', 'http://hrms.pmmsapp.com/images/employees/1531905550.jpg', 'Team Lead', 'Web Developer', '10/31/2015', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 14:40:56', '2018-07-18 14:50:23'),
(10, 70, 'EMP0070', 'http://hrms.pmmsapp.com/images/employees/1531906069.jpg', 'Sr. Web Developer', 'Web Developer', '05/25/2015', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 14:55:22', '2018-07-18 14:57:49'),
(11, 71, 'EMP0071', 'http://hrms.pmmsapp.com/images/employees/1531906545.jpg', 'Sr. Android Developer', 'Sr. Android Developer', '12/01/2017', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 15:04:52', '2018-07-18 15:05:45'),
(12, 72, 'EMP0072', 'http://hrms.pmmsapp.com/images/employees/1549688089.jpg', 'Android Developer', 'Android Developer (Fresher)', '07/16/2018', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 15:11:19', '2019-02-09 11:40:44'),
(13, 73, 'EMP0073', 'http://hrms.pmmsapp.com/images/employees/1531907355.jpg', 'Android Developer', 'Trainee', '02/01/2018', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 15:17:36', '2018-07-18 15:19:15'),
(14, 74, 'EMP0074', 'http://hrms.pmmsapp.com/images/employees/1531918170.jpeg', 'Web Developer', 'Trainee', '07/01/2018', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 15:25:20', '2018-07-18 18:19:30'),
(15, 75, 'EMP0075', 'http://hrms.pmmsapp.com/images/employees/1549688268.jpg', 'PHP Web Developer', 'PHP  Trainee', '07/01/2018', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 15:31:46', '2019-02-09 11:44:12'),
(16, 76, 'EMP0076', 'http://hrms.pmmsapp.com/images/employees/default-user.png', 'BDE', 'BDE', '07/16/2018', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 1, '2018-07-18 15:35:36', '2018-07-18 18:35:51'),
(17, 77, 'EMP0077', 'http://hrms.pmmsapp.com/images/employees/1531909062.jpg', NULL, 'Web Developer (PHP)', '02/20/2018', 'active', NULL, NULL, NULL, 30, NULL, NULL, 0, 0, '2018-07-18 15:42:50', '2018-07-18 15:47:42'),
(18, 79, 'EMP0079', 'http://hrms.pmmsapp.com/images/employees/1550221980.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, '2019-02-09 10:30:52', '2019-02-15 14:43:00'),
(19, 80, 'EMP0080', 'http://hrms.pmmsapp.com/images/employees/default-user.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2019-02-28 13:15:49', '2019-02-28 13:15:49'),
(20, 81, 'EMP0081', 'http://hrms.pmmsapp.com/images/employees/default-user.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, '2019-03-15 17:57:26', '2019-03-15 17:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_personal_details`
--

CREATE TABLE `employee_personal_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aadhar_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_holder_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `martial_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anniversary_date` varbinary(255) DEFAULT NULL,
  `personal_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_contact_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_personal_details`
--

INSERT INTO `employee_personal_details` (`id`, `user_id`, `address`, `phone_number`, `aadhar_no`, `account_holder_name`, `bank_name`, `ifsc_code`, `bank_account`, `martial_status`, `dob`, `anniversary_date`, `personal_email`, `father_name`, `mother_name`, `parent_contact_number`, `created_at`, `updated_at`) VALUES
(8, 68, 'SS 4/356 Vibhav Khand Gomtinagar Lucknow', '9452672531', '8299224866', 'Abhishek Kumar Mishra', 'Axis Bank', 'UTIB0001550', '915010052774436', 'unmarried', '08/21/1992', NULL, 'abhimishrait@gmail.com', 'Anil Kumar Mishra', 'Geeta Mishra', '9811636553', '2018-07-18 14:30:12', '2018-07-18 14:30:12'),
(9, 69, '44 Purvachanl enclave semra chinhat lucknow 226010', '8726050344', NULL, 'Ajay Kumar', 'Axis Bank', 'UTIB0001550', '915010052774546', 'unmarried', '07/29/1989', NULL, 'ajaylpu89@gmail.com', 'Jai Prakash', 'Tara Devi', '8968717762', '2018-07-18 14:40:56', '2018-07-18 14:42:41'),
(10, 70, 'ANDKPG College collany babhnan gonda 271313', '7084754282', NULL, 'Puneet Mishra', 'Axis Bank', 'UTIB0001550', '915010052772168', 'unmarried', '07/20/1992', NULL, 'puneetm65@gmail.com', 'Chandra Bhushan Mishra', 'Meera Mishra', '9532871044', '2018-07-18 14:55:22', '2018-07-18 14:55:22'),
(11, 71, 'Athagawan Duban Antu Pratapgarh', '9140279768', NULL, 'Abhishek Dubey', 'Axis Bank', 'UTIB0001550', '917010038314607', 'married', '07/10/1993', 0x30342f32392f32303138, 'abhishekdubey.pbh@gmail.com', 'Awadh Bihari Dubey', 'Shobha Dubey', '9918681610', '2018-07-18 15:04:52', '2018-07-18 15:04:52'),
(12, 72, '631/126 Surendra Nagar Mulayam nagar lucknow 227105', '8953565632', NULL, 'Pramod Yadav', 'Axis Bank', NULL, NULL, 'unmarried', '02/22/1995', NULL, 'pramodyadav2205@gmail.com', 'R S Yadav', 'Sharada Devi', '8953565632', '2018-07-18 15:11:19', '2019-02-09 11:43:06'),
(13, 73, '21 LIG Rampuram, Shyam Nagar Kanpur 208013', '7275202854', NULL, 'Shailesh Singh Yadav', 'Axis Bank', 'UTIB0001550', '918010022575668', 'unmarried', '07/27/1993', NULL, 'shailesh2771993@gmail.com', 'H. S. Yadav', 'Vimala Devi', '9839891021', '2018-07-18 15:17:36', '2018-07-18 15:17:36'),
(14, 74, '9A Ghazinagar Takrohi Bazaar Indranagar Lucknow', '7007922716', NULL, NULL, NULL, NULL, NULL, 'unmarried', '08/14/1994', NULL, 'amitchaurasiya1408@gmail.com', 'Ram Narayan Chaurasiya', 'Ram Beti', NULL, '2018-07-18 15:25:20', '2019-03-04 10:01:05'),
(15, 75, 'gorakhpur', '7388814149', NULL, NULL, NULL, NULL, NULL, 'unmarried', '04/02/1997', NULL, 'saumya.rpm.sg@gmail.com', 'Santosh Kumar', 'Mala Gupta', '9415571048', '2018-07-18 15:31:46', '2019-02-09 10:28:18'),
(16, 76, '18E/8A Kareli Allahanad', '9935792496', NULL, NULL, NULL, NULL, NULL, 'unmarried', '10/13/1995', NULL, 'arpita@logimetrix.co.in', 'R.C. Upadhyay', 'J. Upadhyay', '9415130585', '2018-07-18 15:35:36', '2019-03-04 10:00:55'),
(17, 77, '1/666 vishal khand, Gomti nagar, Lucknow', '7081628885', NULL, NULL, NULL, NULL, NULL, 'married', '08/22/1994', 0x30362f30322f32303137, 'raghugkp10@gmail.com', 'Mr. Manbahadur Singh', 'Mrs. Usha Devi', NULL, '2018-07-18 15:42:50', '2018-07-18 15:42:50'),
(19, 79, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'unmarried', '07/15/1996', NULL, NULL, NULL, NULL, NULL, '2019-02-09 10:30:52', '2019-02-09 10:30:52'),
(20, 80, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-28 13:15:49', '2019-02-28 13:15:49'),
(21, 81, NULL, '7852888882', NULL, NULL, NULL, NULL, NULL, 'unmarried', NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-15 17:57:26', '2019-03-15 17:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_previous_employments`
--

CREATE TABLE `employee_previous_employments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `total_experience` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_company_details` text COLLATE utf8mb4_unicode_ci,
  `last_company_joining_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_company_relieving` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_company_salary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_join_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_previous_employments`
--

INSERT INTO `employee_previous_employments` (`id`, `user_id`, `total_experience`, `last_company_details`, `last_company_joining_date`, `last_company_relieving`, `last_company_salary`, `first_join_date`, `created_at`, `updated_at`) VALUES
(8, 68, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 14:30:12', '2018-07-18 14:30:12'),
(9, 69, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 14:40:57', '2018-07-18 14:40:57'),
(10, 70, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 14:55:22', '2018-07-18 14:55:22'),
(11, 71, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 15:04:52', '2018-07-18 15:04:52'),
(12, 72, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 15:11:19', '2018-07-18 15:11:19'),
(13, 73, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 15:17:36', '2018-07-18 15:17:36'),
(14, 74, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 15:25:20', '2018-07-18 15:25:20'),
(15, 75, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 15:31:46', '2018-07-18 15:31:46'),
(16, 76, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-18 15:35:36', '2018-07-18 15:35:36'),
(17, 77, '3.7 Years', 'Coding Brains  Software Solution Private limited.', '02/01/2016', '02/14/2018', '18000', NULL, '2018-07-18 15:42:50', '2018-07-18 15:45:59'),
(19, 79, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-09 10:30:52', '2019-02-09 10:30:52'),
(20, 80, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-28 13:15:49', '2019-02-28 13:15:49'),
(21, 81, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-15 17:57:26', '2019-03-15 17:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_projects`
--

CREATE TABLE `employee_projects` (
  `id` int(11) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `reporting_to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `from_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feedback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_projects`
--

INSERT INTO `employee_projects` (`id`, `user_id`, `reporting_to`, `project_id`, `from_date`, `end_date`, `project_status`, `feedback`, `created_at`, `updated_at`) VALUES
(1, 77, '68', 1, '07/05/2018', '08/31/2018', '0', 'test', '2018-07-18 17:36:23', '2018-07-18 17:39:00'),
(2, 71, '68', 2, '03/01/2018', '07/20/2018', '0', 'Target data is near', '2018-07-18 17:42:33', '2018-07-18 17:50:27'),
(3, 69, '68', 4, '07/01/2018', '07/31/2018', '0', 'complete the dashboard and other work asap', '2018-07-18 17:44:07', '2018-07-18 17:44:07'),
(4, 71, '68', 5, '11/24/2016', '11/30/2018', '0', 'test', '2018-07-18 17:46:18', '2018-07-18 17:46:18'),
(5, 73, '71', 2, '07/01/2018', '07/20/2018', '0', 'test', '2018-07-18 17:49:13', '2018-07-18 17:49:13'),
(6, 74, '70', 2, '07/01/2018', '07/20/2018', '0', 'test', '2018-07-18 17:49:55', '2018-07-18 17:49:55'),
(7, 75, '71', 2, '07/01/2018', '07/20/2018', '0', 'test', '2018-07-18 17:51:15', '2018-07-18 17:51:15'),
(8, 70, '68', 2, '02/21/2018', '07/20/2018', '0', 'web', '2018-07-18 17:52:37', '2018-07-18 17:52:37'),
(11, 74, '77', 6, '07/01/2018', '05/31/2019', '0', 'test', '2018-07-18 17:58:49', '2019-02-09 18:41:55'),
(12, 75, '77', 6, '07/01/2018', '08/15/2018', '0', 'test', '2018-07-18 17:59:22', '2018-07-18 17:59:22'),
(13, 77, '68', 6, '07/01/2018', '08/31/2018', '0', 'test', '2018-07-18 17:59:58', '2018-07-18 17:59:58'),
(14, 76, '68', 7, '07/01/2018', '08/31/2019', '0', 'test', '2018-07-18 18:03:18', '2018-07-18 18:03:18'),
(15, 76, '68', 8, '07/01/2018', '07/20/2019', '0', 'test', '2018-07-18 18:03:47', '2018-07-18 18:03:47'),
(16, 76, '68', 9, '07/01/2018', '07/31/2019', '0', 'test', '2018-07-18 18:04:27', '2018-07-18 18:04:27'),
(17, 76, '68', 10, '07/01/2018', '07/28/2019', '0', 'test', '2018-07-18 18:04:55', '2018-07-18 18:04:55'),
(18, 70, '69', 15, '02/01/2019', '01/29/2020', '0', NULL, '2019-02-09 10:09:24', '2019-02-09 10:09:24'),
(19, 71, '69', 11, '01/25/2019', '07/24/2019', '0', NULL, '2019-02-09 10:10:28', '2019-02-09 10:10:28'),
(20, 69, '69', 11, '01/25/2019', '06/20/2019', '0', NULL, '2019-02-09 10:10:31', '2019-02-09 10:10:31'),
(21, 77, '69', 16, '03/14/2018', '09/19/2019', '0', NULL, '2019-02-09 10:11:05', '2019-02-09 10:11:05'),
(22, 75, '69', 17, '02/01/2019', '05/30/2019', '0', NULL, '2019-02-09 10:13:15', '2019-02-09 10:13:15'),
(23, 70, '69', 12, '06/25/2019', '10/28/2019', '0', NULL, '2019-02-09 10:14:43', '2019-02-09 10:14:43'),
(24, 69, '69', 12, '08/13/2018', '09/25/2019', '0', NULL, '2019-02-09 10:14:48', '2019-02-09 10:14:48'),
(25, 72, '77', 14, '02/08/2019', '03/29/2019', '0', NULL, '2019-02-09 10:16:04', '2019-02-09 10:16:04'),
(26, 71, '77', 14, '02/08/2019', '07/31/2019', '0', NULL, '2019-02-09 10:16:59', '2019-02-09 10:16:59'),
(28, 77, '77', 14, '02/01/2019', '02/15/2019', '0', NULL, '2019-02-09 10:42:06', '2019-02-09 10:42:06'),
(29, 77, '69', 18, '06/05/2018', '08/29/2019', '0', NULL, '2019-02-09 12:00:42', '2019-02-09 12:00:42'),
(30, 77, '69', 9, '02/27/2019', '02/28/2019', '0', NULL, '2019-02-15 14:47:39', '2019-02-15 14:47:39');

-- --------------------------------------------------------

--
-- Table structure for table `eods`
--

CREATE TABLE `eods` (
  `id` int(11) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `date_of_eod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `hours_spent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `eods`
--

INSERT INTO `eods` (`id`, `user_id`, `date_of_eod`, `project_id`, `hours_spent`, `task`, `comment`, `created_at`, `updated_at`) VALUES
(1, 71, '02/09/2019', 2, '4', 'Test', NULL, '2019-02-09 11:29:41', '2019-02-09 11:29:41'),
(2, 71, '02/09/2019', 1, '4', 'Test', NULL, '2019-02-09 11:29:41', '2019-02-09 11:29:41'),
(3, 72, '02/09/2019', 1, '2Hr', 'login through firebase id(working)', NULL, '2019-02-09 18:30:36', '2019-02-09 18:30:36'),
(4, 72, '02/09/2019', 1, '1Hr', 'send scan data to server(done)', NULL, '2019-02-09 18:30:36', '2019-02-09 18:30:36'),
(5, 72, '02/09/2019', 1, '1Hr', 'added language selection module(done)', NULL, '2019-02-09 18:30:36', '2019-02-09 18:30:36'),
(6, 72, '02/09/2019', 1, '2Hr', 'added logout button and their functionality(done)', NULL, '2019-02-09 18:30:36', '2019-02-09 18:30:36'),
(7, 72, '02/09/2019', 1, '2Hr', 'added scan QR code module(done)', NULL, '2019-02-09 18:30:36', '2019-02-09 18:30:36'),
(8, 72, '02/09/2019', 5, '30min', 'Support', NULL, '2019-02-09 18:30:36', '2019-02-09 18:30:36'),
(9, 72, '02/09/2019', 2, '30', 'Support', NULL, '2019-02-09 18:30:36', '2019-02-09 18:30:36'),
(10, 74, '02/09/2019', 6, '2', 'Expense Module -> Client side validation in add new expense', NULL, '2019-02-09 18:36:25', '2019-02-09 18:36:25'),
(11, 74, '02/09/2019', 6, '1', 'Vendor Module -> Active Vendor (View)', NULL, '2019-02-09 18:36:25', '2019-02-09 18:36:25'),
(12, 74, '02/09/2019', 6, '1', 'Vendor Module -> Database tables to save data of vendor', NULL, '2019-02-09 18:36:25', '2019-02-09 18:36:25'),
(13, 74, '02/09/2019', 6, '4', 'Vendor Module -> Add New Vendor (New Form)', NULL, '2019-02-09 18:36:25', '2019-02-09 18:36:25'),
(14, 79, '02/09/2019', 2, '9', '1- Understanding code of Shaathi\r\n2-Add Discount list in order management(working)', NULL, '2019-02-09 18:39:31', '2019-02-09 18:39:31'),
(15, 77, '02/09/2019', 18, '1', 'Support to Teachers (Timetable module)', NULL, '2019-02-09 18:40:36', '2019-02-09 18:40:36'),
(16, 77, '02/09/2019', 14, '7', '- Update Invitation Status when scan QR Code (DONE)\r\n- Support to Teachers (Student Attendance Report Module)\r\n-Support to Mohit & Pramod', NULL, '2019-02-09 18:40:36', '2019-02-09 18:40:36'),
(17, 75, '02/09/2019', 17, '2', 'resolving css and js issue in webnest website', NULL, '2019-02-09 18:44:38', '2019-02-09 18:44:38'),
(18, 75, '02/09/2019', 17, '4', 'add Category and about us page in weavnest website', NULL, '2019-02-09 18:44:38', '2019-02-09 18:44:38'),
(19, 75, '02/09/2019', 17, '1', 'Support Niharika to understanding code', NULL, '2019-02-09 18:44:38', '2019-02-09 18:44:38'),
(20, 75, '02/09/2019', 17, '2', 'R&D on weavnest  theme', NULL, '2019-02-09 18:44:38', '2019-02-09 18:44:38'),
(21, 69, '02/09/2019', 3, '2', 'Meeting with raj sir on Acme Esr generate spend time Cron calculation', NULL, '2019-02-09 18:49:35', '2019-02-09 18:49:35'),
(22, 69, '02/09/2019', 11, '2', 'Meeting with Shubham on Sync data', NULL, '2019-02-09 18:49:35', '2019-02-09 18:49:35'),
(23, 69, '02/09/2019', 1, '4', 'HTML Design of Room Status', NULL, '2019-02-09 18:49:35', '2019-02-09 18:49:35'),
(24, 71, '02/09/2019', 11, '2', 'Discussion with Shubham Sir', 'I forget', '2019-02-11 10:26:08', '2019-02-11 10:26:08'),
(25, 71, '02/09/2019', 1, '2', 'Worked On EMS Application :\r\n- create event module (DONE)\r\n- hit api of get event list (DONE)\r\n- show data of events list (DONE)', 'I forget', '2019-02-11 10:26:08', '2019-02-11 10:26:08'),
(26, 71, '02/09/2019', 11, '4', 'testing and resolving issues', 'I forget', '2019-02-11 10:26:08', '2019-02-11 10:26:08'),
(27, 75, '02/11/2019', 17, '2', 'Support niharika in learning php', NULL, '2019-02-11 18:32:09', '2019-02-11 18:32:09'),
(28, 75, '02/11/2019', 17, '2', 'Worked on the view of gallery page', NULL, '2019-02-11 18:32:09', '2019-02-11 18:32:09'),
(29, 75, '02/11/2019', 17, '2', 'add js in webnest website', NULL, '2019-02-11 18:32:09', '2019-02-11 18:32:09'),
(30, 75, '02/11/2019', 17, '2', 'add css in webnest website', NULL, '2019-02-11 18:32:09', '2019-02-11 18:32:09'),
(31, 79, '02/11/2019', 2, '8', 'Understanding code\r\n-Order Management', NULL, '2019-02-11 18:39:59', '2019-02-11 18:39:59'),
(32, 71, '02/11/2019', 1, '4', '- create invitation module (DONE)\r\n- hit api of invitation list (DONE)\r\n- show data of invitation list (DONE)', NULL, '2019-02-11 18:40:50', '2019-02-11 18:40:50'),
(33, 71, '02/11/2019', 1, '4', '- create edit and update option in invitation list (DONE)\r\n- code merged of pramod and me (DONE)\r\n- testing and resolve (DONE)', NULL, '2019-02-11 18:40:50', '2019-02-11 18:40:50'),
(34, 77, '02/11/2019', 14, '6', '-Support to Mohit & Pramod\r\n- API support', NULL, '2019-02-11 18:42:37', '2019-02-11 18:42:37'),
(35, 77, '02/11/2019', 16, '2', '- Call to different email service provider', NULL, '2019-02-11 18:42:37', '2019-02-11 18:42:37'),
(36, 69, '02/11/2019', 1, '3', 'Dynamic Rooms\r\n- Show Room Name, Room No. with free and Occupied status with teacher name', NULL, '2019-02-11 18:43:31', '2019-02-11 18:43:31'),
(37, 69, '02/11/2019', 1, '1', 'Design of Room Page', NULL, '2019-02-11 18:43:31', '2019-02-11 18:43:31'),
(38, 69, '02/11/2019', 3, '3', 'Meeting with raj sir on android and web work status\r\n- worksheet send on email \r\n- update fsr PIU, AC, BC table datatype in excel sheet', NULL, '2019-02-11 18:43:31', '2019-02-11 18:43:31'),
(39, 69, '02/11/2019', 3, '1', 'check fsr_details and spare part table for spare part quantity', NULL, '2019-02-11 18:43:31', '2019-02-11 18:43:31'),
(40, 73, '02/11/2019', 3, '8', 'Check Login  api Details \r\nMeeting with Raj Sir.\r\nCheck FSr details in local database (Done).', NULL, '2019-02-11 18:48:00', '2019-02-11 18:48:00'),
(41, 75, '02/12/2019', 17, '2', 'R&D on the js and css used in the weavnest theme', NULL, '2019-02-12 18:22:54', '2019-02-12 18:22:54'),
(42, 75, '02/12/2019', 17, '2', 'support niharika', NULL, '2019-02-12 18:22:55', '2019-02-12 18:22:55'),
(43, 75, '02/12/2019', 17, '2', 'adding js in the theme', NULL, '2019-02-12 18:22:55', '2019-02-12 18:22:55'),
(44, 75, '02/12/2019', 17, '2', 'adding css in the theme', NULL, '2019-02-12 18:22:55', '2019-02-12 18:22:55'),
(45, 73, '02/12/2019', 12, '8', '- Add Current Latitude & Longitude(Done)\r\n- Show Distance according to Current Latitude & Longitude(Done)', NULL, '2019-02-12 18:28:17', '2019-02-12 18:28:17'),
(46, 79, '02/12/2019', 11, '2', 'Testing Drone By Flying With Mohit', NULL, '2019-02-12 18:35:49', '2019-02-12 18:35:49'),
(47, 79, '02/12/2019', 2, '6', 'Understanding Code', NULL, '2019-02-12 18:35:49', '2019-02-12 18:35:49'),
(48, 71, '02/12/2019', 14, '2', 'Worked On VMS-BIPE :\r\n- crash resolve issue of create module (DONE)\r\n- resolve missing field in create module (Working)', NULL, '2019-02-12 18:36:06', '2019-02-12 18:36:06'),
(49, 71, '02/12/2019', 14, '4', 'Worked On BIPE-EMS :\r\n- create received module (DONE)\r\n- hit api of received module (DONE)\r\n- show data of received module (DONE)', NULL, '2019-02-12 18:36:06', '2019-02-12 18:36:06'),
(50, 71, '02/12/2019', 11, '2', 'testing', NULL, '2019-02-12 18:36:06', '2019-02-12 18:36:06'),
(51, 71, '02/12/2019', 14, '2', 'Worked On VMS-BIPE :\r\n- crash resolve issue of create module (DONE)\r\n- resolve missing field in create module (Working)', NULL, '2019-02-12 18:36:11', '2019-02-12 18:36:11'),
(52, 71, '02/12/2019', 14, '4', 'Worked On BIPE-EMS :\r\n- create received module (DONE)\r\n- hit api of received module (DONE)\r\n- show data of received module (DONE)', NULL, '2019-02-12 18:36:11', '2019-02-12 18:36:11'),
(53, 71, '02/12/2019', 11, '2', 'testing', NULL, '2019-02-12 18:36:11', '2019-02-12 18:36:11'),
(54, 77, '02/12/2019', 1, '2', '-Screenshots of BIPE (DONE)\r\n- meeting & demo', NULL, '2019-02-12 18:39:50', '2019-02-12 18:39:50'),
(55, 77, '02/12/2019', 14, '6', '- Worked VMS - BIPE (Web & Api)\r\n-Support to @MOHIT', NULL, '2019-02-12 18:39:50', '2019-02-12 18:39:50'),
(56, 77, '02/13/2019', 14, '4', '- get user detail API\r\n- get Events API\r\n- support to mohit\r\n- Demo of EMS to BIPE Teacher (Rajat)', NULL, '2019-02-13 18:27:03', '2019-02-13 18:27:03'),
(57, 71, '02/13/2019', 5, '1', 'Worked On NDDB-AIT :\r\n- resolve issue of user, pd report not show (Done)', NULL, '2019-02-13 18:32:46', '2019-02-13 18:32:46'),
(58, 71, '02/13/2019', 11, '3', '- improve efficiency of sync data (Done)', NULL, '2019-02-13 18:32:46', '2019-02-13 18:32:46'),
(59, 71, '02/13/2019', 14, '4', '- code review of VMS (Done)\r\n- text changes in create visit module of application (Done)\r\n- save image (Done)\r\n- resolved real time notification (firebase) (Working)', NULL, '2019-02-13 18:32:46', '2019-02-13 18:32:46'),
(60, 79, '02/13/2019', 2, '8', '1-Code Review \r\n 2-Working On Other Projects', NULL, '2019-02-13 18:37:03', '2019-02-13 18:37:03'),
(61, 75, '02/13/2019', 17, '2', 'R&D on the cart gallery in js', NULL, '2019-02-13 18:38:01', '2019-02-13 18:38:01'),
(62, 75, '02/13/2019', 17, '4', 'support  niharika  in learning php', NULL, '2019-02-13 18:38:01', '2019-02-13 18:38:01'),
(63, 75, '02/13/2019', 17, '2', 'implement js and css in  weavnest theme', NULL, '2019-02-13 18:38:01', '2019-02-13 18:38:01'),
(64, 69, '02/13/2019', 3, '1', '- Clear site id\r\n- Check spare part quantity by using api hit on postman', NULL, '2019-02-13 18:38:19', '2019-02-13 18:38:19'),
(65, 69, '02/13/2019', 10, '3.5', 'Meeting with sumit sir and get requirement for testing app. \r\nSupport Android team', NULL, '2019-02-13 18:38:19', '2019-02-13 18:38:19'),
(66, 69, '02/13/2019', 12, '2', 'get current latitude and longitude', NULL, '2019-02-13 18:38:19', '2019-02-13 18:38:19'),
(67, 69, '02/13/2019', 13, '0.5', 'send email to naman sir', NULL, '2019-02-13 18:38:19', '2019-02-13 18:38:19'),
(68, 69, '02/13/2019', 11, '1', 'Screenshot to share with shubham\r\ncall with shubham', NULL, '2019-02-13 18:38:19', '2019-02-13 18:38:19'),
(69, 73, '02/13/2019', 12, '3', 'Other projects \r\nLogin Page implementation', NULL, '2019-02-13 18:38:56', '2019-02-13 18:38:56'),
(70, 73, '02/13/2019', 12, '5', '- Validate day start according to Current Latitude & Longitude Distance.- Add green & red color on distance text.', NULL, '2019-02-13 18:38:56', '2019-02-13 18:38:56'),
(71, 74, '02/13/2019', 6, '6', 'Vendor Module -> Add new vendor (Done)\r\n-> Edit Vendor Profile (Done)\r\n-> Deactivate Vendor Profile (Done)', NULL, '2019-02-13 18:44:26', '2019-02-13 18:44:26'),
(72, 74, '02/13/2019', 6, '2', 'Master Data - > state master (view, add, update, delete)', NULL, '2019-02-13 18:44:26', '2019-02-13 18:44:26'),
(73, 69, '02/14/2019', 3, '4', 'Meeting with raj\r\n- check version of app in login api\r\n- unused variable attend_time in startday api at line 3759\r\n- check date format in application end\r\n- comment log code in startDay at line no 3789 (Done)', NULL, '2019-02-14 18:22:46', '2019-02-14 18:22:46'),
(74, 69, '02/14/2019', 1, '4', 'Classroom Status\r\n- show period time (Done)\r\n- show all today period list(period, teacher, subject) by click on particular period option (Done)', NULL, '2019-02-14 18:22:46', '2019-02-14 18:22:46'),
(75, 79, '02/14/2019', 2, '8', 'Code Review.', NULL, '2019-02-14 18:24:04', '2019-02-14 18:24:04'),
(76, 73, '02/14/2019', 12, '5', '-Review acme code-Check 0.0 in reach-at-site and send a response in local', NULL, '2019-02-14 18:28:24', '2019-02-14 18:28:24'),
(77, 73, '02/14/2019', 2, '3', 'Change base URL in Saathi app\r\nGenerate apk on Saathi app', NULL, '2019-02-14 18:28:24', '2019-02-14 18:28:24'),
(78, 74, '02/14/2019', 6, '8', '-> Attach Documents in edit and create vendor (Done)\r\n-> View Vendor details (Done)\r\n-> Deactivated Vendor list (Done) \r\n-> Deactivate and activate vendor (Done)', NULL, '2019-02-14 18:36:34', '2019-02-14 18:36:34'),
(80, 79, '02/15/2019', 19, '8', 'Implement Facebook Login', NULL, '2019-02-15 18:36:40', '2019-02-15 18:36:40'),
(81, 73, '02/15/2019', 2, '1', 'Change Base URL in  apptaskmonitor\r\nGenerate apk on Saathi app', NULL, '2019-02-15 18:37:00', '2019-02-15 18:37:00'),
(82, 73, '02/15/2019', 3, '4', 'test fsr form details \r\nTest Nms form and check save data on local database.\r\n\r\nCheck Login  api Details', NULL, '2019-02-15 18:37:00', '2019-02-15 18:37:00'),
(83, 76, '02/15/2019', 17, '6', '-R&D on weavenest\r\n-downloaded images of sarees\r\n-changes in content', NULL, '2019-02-15 18:39:00', '2019-02-15 18:39:00'),
(84, 75, '02/15/2019', 17, '8', 'Change text ,image,download image of the home page\r\nR&D on the image of weavnest website', NULL, '2019-02-15 18:39:17', '2019-02-15 18:39:17'),
(85, 74, '02/15/2019', 19, '2', 'Meetings in Tech and Infra office', NULL, '2019-02-15 18:45:37', '2019-02-15 18:45:37'),
(86, 74, '02/15/2019', 6, '6', 'Master Data ->Employee Role Master -> Role list (Done) ->Add, edit role (Done) -> Activate, Deacticate and Delete (Done)', NULL, '2019-02-15 18:45:37', '2019-02-15 18:45:37'),
(87, 69, '02/15/2019', 1, '2', 'Add validation\r\n- show data according to current time in Room Details view list', NULL, '2019-02-15 18:47:10', '2019-02-15 18:47:10'),
(88, 69, '02/15/2019', 19, '1', 'Discussion with manisha ma\'am and check domain', NULL, '2019-02-15 18:47:10', '2019-02-15 18:47:10'),
(89, 69, '02/15/2019', 3, '3', 'Test Job details Form(Schedule, Move to Site, Reach at site, verify site, completed job) fill the form value by android application and the data properly saved in database table. Please find the attached screenshot.', NULL, '2019-02-15 18:47:10', '2019-02-15 18:47:10'),
(90, 69, '02/15/2019', 3, '2', 'Generate FSR PDF for Two Call log no.', NULL, '2019-02-15 18:47:10', '2019-02-15 18:47:10'),
(91, 74, '02/16/2019', 6, '6', 'Master Data -> Employee Role type and roles (view and flow) (Done)\r\n-> PO & Sites Module (Working)\r\n-> Expense -> site expense (View)-Done, show related data (Working)', NULL, '2019-02-16 18:32:26', '2019-02-16 18:32:26'),
(92, 74, '02/16/2019', 6, '2', 'Database Tables Correction', NULL, '2019-02-16 18:32:26', '2019-02-16 18:32:26'),
(93, 76, '02/16/2019', 17, '8', 'worked on weavenest:\r\n-made changes on about page  and home page\r\n-R&D on images and content', NULL, '2019-02-16 18:32:35', '2019-02-16 18:32:35'),
(94, 69, '02/16/2019', 5, '5', 'Worked on AMR User AIT00141 \r\n - reslove login issue\r\n Support AMR User AIT00140\r\n - Sync data of Farmer and \r\n - Call to AIT', NULL, '2019-02-16 18:36:36', '2019-02-16 18:36:36'),
(95, 69, '02/16/2019', 19, '3', 'Setup of charoite website\r\n - download logimetrix techsolutions website code and db\r\n - upload website code and db on pmms server for charoite website\r\n - Create mail id', NULL, '2019-02-16 18:36:36', '2019-02-16 18:36:36'),
(96, 79, '02/19/2019', 1, '6', 'Implement Dashboard  Layout In Student Application', NULL, '2019-02-19 18:31:30', '2019-02-19 18:31:30'),
(97, 75, '02/19/2019', 17, '8', 'Worked on the tissue page of weavnest website\r\n - Worked on the contact us page of weavnest website\r\n - meeting with richa mam regarding weavnest website', NULL, '2019-02-19 18:34:09', '2019-02-19 18:34:09'),
(98, 75, '02/19/2019', 17, '8', 'Worked on the tissue page of weavnest website\r\n - Worked on the contact us page of weavnest website\r\n - meeting with richa mam regarding weavnest website', NULL, '2019-02-19 18:34:11', '2019-02-19 18:34:11'),
(99, 75, '02/19/2019', 17, '8', 'Worked on the tissue page of weavnest website\r\n - Worked on the contact us page of weavnest website\r\n - meeting with richa mam regarding weavnest website', NULL, '2019-02-19 18:34:13', '2019-02-19 18:34:13'),
(100, 69, '02/19/2019', 1, '15 m', 'Call with Anupam for ERP discussion', NULL, '2019-02-19 18:34:42', '2019-02-19 18:34:42'),
(101, 69, '02/19/2019', 15, '45 m', 'Support Saahaj\r\n  - Add master data of district', NULL, '2019-02-19 18:34:42', '2019-02-19 18:34:42'),
(102, 69, '02/19/2019', 5, '6', 'Worked on SAG\r\n- correction in sale data report\r\n  1. change by default to and from date value\r\n  2. change logic of current, previous and YTD Sale columns value.\r\n\r\n- correction in sale data breed wise report\r\n  1. change by default to and from date value\r\n  2. change logic of current, previous and YTD Sale columns value.\r\n\r\n- correction in sale data breed report\r\n  1. change by default to and from date value\r\n  2. change logic of current, previous and YTD Sale columns value.    \r\n\r\n  Call with SAG user for report logic discussion', NULL, '2019-02-19 18:34:42', '2019-02-19 18:34:42'),
(103, 69, '02/19/2019', 3, '2', 'Worked on Acme\r\n  - clear site id ASNH52008\r\n  - check FQB admin login and loading issue\r\n  - check user login of user id EI3811', NULL, '2019-02-19 18:34:42', '2019-02-19 18:34:42'),
(104, 76, '02/19/2019', 17, '8', '-changes in about page\r\n-changes on home page\r\n-meeting with Richa maam', NULL, '2019-02-19 18:35:33', '2019-02-19 18:35:33'),
(105, 74, '02/19/2019', 6, '4', 'Asset Type Module \r\n-> asset type (add, view, delete, active, deactive)', NULL, '2019-02-19 18:39:17', '2019-02-19 18:39:17'),
(106, 74, '02/19/2019', 6, '4', 'Attendance Module \r\n-> data correction\r\n-> view correction', NULL, '2019-02-19 18:39:17', '2019-02-19 18:39:17'),
(107, 72, '02/19/2019', 5, '8', 'EOD:\r\nWorked on AMR\r\n- fixed bug in layout\r\n\r\nSupport on SAG\r\nSupport on Saathi', NULL, '2019-02-20 18:26:29', '2019-02-20 18:26:29'),
(108, 79, '02/20/2019', 1, '8', '-Implement Dashboard  Layout In Student Application.\r\n-Implement Navigation Side Bar Layout in Student Application', NULL, '2019-02-20 18:26:34', '2019-02-20 18:26:34'),
(109, 75, '02/20/2019', 17, '8', 'worked on weavenest\r\n- worked on the design of the website\r\n- changes on all the pages\r\n- convert weavnest Website on zend framework(Working)', NULL, '2019-02-20 18:28:17', '2019-02-20 18:28:17'),
(110, 76, '02/20/2019', 17, '8', '-worked on the design of the website\r\n-changes on all the pages', NULL, '2019-02-20 18:28:27', '2019-02-20 18:28:27'),
(111, 69, '02/20/2019', 15, '1', 'Support Saahaj\r\n - Call with user SAL00950 for check tracking user data.\r\n - Clear id and check his local db.', NULL, '2019-02-20 18:28:38', '2019-02-20 18:28:38'),
(112, 69, '02/20/2019', 5, '4', '- Map SUB004527 user id with punjab state\r\n  1. update area mapping table data for user id SUB004527.\r\n  2. correction in script and run', NULL, '2019-02-20 18:28:38', '2019-02-20 18:28:38'),
(113, 69, '02/20/2019', 2, '3', '- Upload Van Sale Code on Seema Web Panel.\r\n - Share updated apk with vipin\r\n - Call with Ajay Gaur on a21technologies user management module discussion', NULL, '2019-02-20 18:28:38', '2019-02-20 18:28:38'),
(114, 72, '02/20/2019', 2, '1', 'support to user', NULL, '2019-02-20 18:28:51', '2019-02-20 18:28:51'),
(115, 72, '02/20/2019', 5, '1', 'upload new apk to playstore\r\nsupport to user', NULL, '2019-02-20 18:28:51', '2019-02-20 18:28:51'),
(116, 72, '02/20/2019', 15, '6', '- review code', NULL, '2019-02-20 18:28:51', '2019-02-20 18:28:51'),
(117, 71, '02/20/2019', 2, '2', 'Support A21taskmonitor', NULL, '2019-02-20 18:30:14', '2019-02-20 18:30:14'),
(118, 71, '02/20/2019', 11, '6', '- R&D on Zooming in drone camera (Done)\r\n- Follow FIFO picture should sync  (Done)\r\n- make filter that take only drone images from drone repository (Done)\r\n- testing  (Done)', NULL, '2019-02-20 18:30:14', '2019-02-20 18:30:14'),
(119, 74, '02/20/2019', 19, '3', 'Prepared Worksheet of BIPE', NULL, '2019-02-20 18:34:19', '2019-02-20 18:34:19'),
(120, 74, '02/20/2019', 6, '5', 'Asset module -> asset type\r\n-> asset', NULL, '2019-02-20 18:34:19', '2019-02-20 18:34:19'),
(121, 72, '02/21/2019', 5, '3', 'support', NULL, '2019-02-21 18:30:52', '2019-02-21 18:30:52'),
(122, 72, '02/21/2019', 15, '2', 'support', NULL, '2019-02-21 18:30:52', '2019-02-21 18:30:52'),
(123, 72, '02/21/2019', 2, '3', 'support\r\nadd voice command', NULL, '2019-02-21 18:30:52', '2019-02-21 18:30:52'),
(124, 75, '02/21/2019', 17, '8', '- convert weavnest website on zend(Complete)\r\n- change css and js of weavnest\r\n- making  admin pannel of website(working)', NULL, '2019-02-21 18:36:15', '2019-02-21 18:36:15'),
(125, 75, '02/22/2019', 17, '8', '- (add,delete,update) category and sub category master in weavenest admin panel(done)\r\n-  add css and js in the side bar dropdown(done)', NULL, '2019-02-22 18:32:42', '2019-02-22 18:32:42'),
(126, 79, '02/22/2019', 1, '8', '-Implement Dashboard  Layout in Student Application', NULL, '2019-02-22 18:34:29', '2019-02-22 18:34:29'),
(127, 71, '02/23/2019', 15, '4', '- resolved issue of track user data (Done)\r\n- testing from ID\'s SAL00948 and TSE00817 (Done)', NULL, '2019-02-23 18:30:38', '2019-02-23 18:30:38'),
(128, 71, '02/23/2019', 3, '4', 'R & D on mock location', NULL, '2019-02-23 18:30:38', '2019-02-23 18:30:38'),
(129, 72, '02/23/2019', 5, '1', 'call with SAG and AMR client', NULL, '2019-02-23 18:31:32', '2019-02-23 18:31:32'),
(130, 72, '02/23/2019', 2, '1', 'Support to user', NULL, '2019-02-23 18:31:32', '2019-02-23 18:31:32'),
(131, 72, '02/23/2019', 5, '3', 'Worked on AMR:\r\n1.  In Milk Recording List bug fixed\r\n2. sync problem solved\r\n3.  Support to user', NULL, '2019-02-23 18:31:32', '2019-02-23 18:31:32'),
(132, 72, '02/23/2019', 5, '3', 'Worked on SAG\r\n1. Change scenario in Retail Sale (Initiate order) module\r\n2. sync problem fixed\r\n3. Support to user', NULL, '2019-02-23 18:31:32', '2019-02-23 18:31:32'),
(133, 75, '02/23/2019', 17, '8', '- Add Product module in master(add,update,delete)[done]\r\n    - add image in product module[done]\r\n    - View product in master with images [done]', NULL, '2019-02-23 18:33:26', '2019-02-23 18:33:26'),
(134, 79, '02/23/2019', 19, '8', '- Implement Latitude & Longitude(Done)\r\n- R&D on Mock Location', NULL, '2019-02-23 18:40:00', '2019-02-23 18:40:00'),
(135, 69, '02/23/2019', 5, '4', 'Support on AMR\r\n- Call with 8199998509\r\nSupport on Subfre\r\n- Call to jatinder\r\n- Sync Data\r\n- Create new api for delete ait order data by subfre', NULL, '2019-02-23 18:44:49', '2019-02-23 18:44:49'),
(136, 69, '02/23/2019', 15, '4', 'Call with SAL00948 and TSE00817\r\nCorrection in track api', NULL, '2019-02-23 18:44:49', '2019-02-23 18:44:49'),
(137, 75, '02/25/2019', 17, '8', '- add discription on category(done)\r\n- making contact page dynamic(done)\r\n- making category page dynamic(working)', NULL, '2019-02-25 18:32:44', '2019-02-25 18:32:44'),
(138, 79, '02/25/2019', 19, '5', 'Implement Mock Location', NULL, '2019-02-25 18:34:13', '2019-02-25 18:34:13'),
(139, 79, '02/25/2019', 1, '3', 'Implement Time Table Layout in Student Application', NULL, '2019-02-25 18:34:13', '2019-02-25 18:34:13'),
(140, 72, '02/25/2019', 5, '1', 'Call with SAG users', NULL, '2019-02-25 18:34:19', '2019-02-25 18:34:19'),
(141, 72, '02/25/2019', 2, '2', '1. added fake GPS location check on Saathi app', NULL, '2019-02-25 18:34:19', '2019-02-25 18:34:19'),
(142, 72, '02/25/2019', 2, '30min', 'Support to users', NULL, '2019-02-25 18:34:19', '2019-02-25 18:34:19'),
(143, 72, '02/25/2019', 19, '30min', 'Support on AMR', NULL, '2019-02-25 18:34:19', '2019-02-25 18:34:19'),
(144, 72, '02/25/2019', 5, '2', '1. do some changes in order module\r\n 2. upload APK on playstore', NULL, '2019-02-25 18:34:19', '2019-02-25 18:34:19'),
(145, 72, '02/25/2019', 5, '2', 'support to users', NULL, '2019-02-25 18:34:19', '2019-02-25 18:34:19'),
(146, 76, '02/25/2019', 17, '8', '-implemented count() on icons.\r\n-validation on products.', NULL, '2019-02-25 18:34:52', '2019-02-25 18:34:52'),
(147, 72, '02/26/2019', 3, '3', '1. Implementing FAKE GPS Location check(working)', NULL, '2019-02-26 18:31:00', '2019-02-26 18:31:00'),
(148, 72, '02/26/2019', 19, '1', 'Support on AMR', NULL, '2019-02-26 18:31:00', '2019-02-26 18:31:00'),
(149, 72, '02/26/2019', 5, '2', 'Call with Users', NULL, '2019-02-26 18:31:00', '2019-02-26 18:31:00'),
(150, 72, '02/26/2019', 5, '1', 'Support to users', NULL, '2019-02-26 18:31:00', '2019-02-26 18:31:00'),
(151, 72, '02/26/2019', 2, '1', 'Support to users', NULL, '2019-02-26 18:31:00', '2019-02-26 18:31:00'),
(152, 76, '02/26/2019', 17, '8', '-implemented graph and validation', NULL, '2019-02-26 18:32:34', '2019-02-26 18:32:34'),
(153, 74, '02/26/2019', 6, '8', '- Asset Management Module\r\n  -: Asset Type (Add, Edit, Deactivate, Activate, Delete) - Done\r\n  -: Assets (Add, Edit, Deactivate, Activate, Delete) - Done\r\n  -: System (Add, Edit, Deactivate, Activate, Delete) - Done\r\n- Attendance Module\r\n  -: Employee Monthly Attendance View (Done)\r\n  -: Download attendance in excel sheet (Present & Absent only) (Done)', NULL, '2019-02-26 18:35:59', '2019-02-26 18:35:59'),
(154, 79, '02/26/2019', 1, '8', '1-Implement Time Table Layout In Student Application\r\n2-Implement Drop down List In Student Application', NULL, '2019-02-26 18:36:03', '2019-02-26 18:36:03'),
(155, 69, '02/26/2019', 11, '9', 'Setup of Drone Application (Web and database) on Acme Server', NULL, '2019-02-26 18:36:47', '2019-02-26 18:36:47'),
(156, 71, '02/26/2019', 15, '2', '- upload apk (Done)\r\n- resolve issues (login problem) of two users (Done)', NULL, '2019-02-26 18:42:40', '2019-02-26 18:42:40'),
(157, 71, '02/26/2019', 1, '2', 'Worked On Student_BIPE :\r\n- create calendar that shows attendance of monthwise (Working)', NULL, '2019-02-26 18:42:40', '2019-02-26 18:42:40'),
(158, 71, '02/26/2019', 2, '2', 'Support Users', NULL, '2019-02-26 18:42:40', '2019-02-26 18:42:40'),
(159, 71, '02/26/2019', 5, '2', 'Support Users', NULL, '2019-02-26 18:42:40', '2019-02-26 18:42:40'),
(160, 76, '02/27/2019', 17, '8', '-visit on client site', NULL, '2019-02-27 18:33:02', '2019-02-27 18:33:02'),
(161, 74, '02/27/2019', 19, '2', 'SJS support', NULL, '2019-02-27 18:43:59', '2019-02-27 18:43:59'),
(162, 74, '02/27/2019', 1, '6', 'Support to BIPE Teacher', NULL, '2019-02-27 18:43:59', '2019-02-27 18:43:59'),
(163, 72, '02/28/2019', 3, '5', 'Implementing FAKE GPS Location check(working)', NULL, '2019-02-28 18:36:24', '2019-02-28 18:36:24'),
(164, 72, '02/28/2019', 19, '1', 'Support on AMR', NULL, '2019-02-28 18:36:24', '2019-02-28 18:36:24'),
(165, 72, '02/28/2019', 5, '1', 'support', NULL, '2019-02-28 18:36:24', '2019-02-28 18:36:24'),
(166, 72, '02/28/2019', 2, '1', 'support', NULL, '2019-02-28 18:36:24', '2019-02-28 18:36:24'),
(167, 71, '02/28/2019', 1, '6', 'Worked On Student_BIPE :\r\n- create login module (Done)\r\n- hit api of login (Done)\r\n- data save to shared prefernce (Done)\r\n\r\n- Support Ayush', NULL, '2019-02-28 18:41:59', '2019-02-28 18:41:59'),
(168, 71, '02/28/2019', 15, '2', 'User track data in not create in table (working)', NULL, '2019-02-28 18:41:59', '2019-02-28 18:41:59'),
(169, 69, '02/28/2019', 19, '1', 'Support on SJS Maharajganj \r\nSupport on Acme', NULL, '2019-02-28 18:42:18', '2019-02-28 18:42:18'),
(170, 69, '02/28/2019', 15, '1', 'Support on Saahaj', NULL, '2019-02-28 18:42:18', '2019-02-28 18:42:18'),
(171, 69, '02/28/2019', 11, '6', 'Setup for global Ip and correction in php.ini file\r\nMeeting with veer Sir', NULL, '2019-02-28 18:42:18', '2019-02-28 18:42:18'),
(172, 76, '02/28/2019', 17, '8', '-edit product\r\n-implemented layouts', NULL, '2019-02-28 18:44:14', '2019-02-28 18:44:14'),
(173, 69, '03/01/2019', 11, '4', 'Meeting with Veer Sir(For Web application design)\r\n- Change Dashboard Design (Remove padding of panel heading)\r\n- Change manage project details text into view project \r\n- Remove text size all over the application and remove padding of all pages', NULL, '2019-03-01 18:07:08', '2019-03-01 18:07:08'),
(174, 69, '03/01/2019', 3, '1', 'Discussion on PDF generation\r\n- Generate Chandigarh and Himachal Circle PDF', NULL, '2019-03-01 18:07:08', '2019-03-01 18:07:08'),
(175, 69, '03/01/2019', 12, '2', '- Check Attendance APP Login Api\r\n- Check Day Start Api', NULL, '2019-03-01 18:07:08', '2019-03-01 18:07:08'),
(176, 69, '03/01/2019', 12, '1', '- Meeting With Raj Sir on User Attendance Api and day Start Api', NULL, '2019-03-01 18:07:08', '2019-03-01 18:07:08'),
(177, 75, '03/01/2019', 17, '8', '-make  new arrival dynamic page\r\n-add a new arrival check box in a product module of admin pannel\r\n- show offer and selling price of a product\r\n-show and add review in a admin pannel\r\n- insert review from database in website\r\n - show product review model in admin pannel(Working)', NULL, '2019-03-01 18:18:48', '2019-03-01 18:18:48'),
(178, 72, '03/01/2019', 5, '3', '1.sync problem solved( with the help of Raghu Sir )', NULL, '2019-03-01 18:30:41', '2019-03-01 18:30:41'),
(179, 72, '03/01/2019', 5, '3', 'Support to users', NULL, '2019-03-01 18:30:41', '2019-03-01 18:30:41'),
(180, 72, '03/01/2019', 19, '1', 'Support on AMR', NULL, '2019-03-01 18:30:41', '2019-03-01 18:30:41'),
(181, 72, '03/01/2019', 2, '1', 'support', NULL, '2019-03-01 18:30:41', '2019-03-01 18:30:41'),
(182, 76, '03/01/2019', 13, '6', '-discussion with team\r\n-ppt on inventory Management System', NULL, '2019-03-01 18:32:54', '2019-03-01 18:32:54'),
(183, 76, '03/01/2019', 17, '2', '-content collection.', NULL, '2019-03-01 18:32:54', '2019-03-01 18:32:54'),
(184, 79, '02/28/2019', 1, '8', '-Implement Time Table Layout in Student Application (Working)\r\n  -Hit API In Student Application(Done)', NULL, '2019-03-01 18:34:30', '2019-03-01 18:34:30'),
(185, 79, '03/01/2019', 1, '8', '-Implement Time Table Layout in Student Application (Working)\r\n    -Implement Spinner in Student Application And Show  Data(Done)\r\n    -Hit API In Student Application(Done)', NULL, '2019-03-01 18:35:04', '2019-03-01 18:35:04'),
(186, 74, '03/01/2019', 19, '2', '\"Meeting on Inventory Management APP (Requirement)', NULL, '2019-03-01 18:38:37', '2019-03-01 18:38:37'),
(187, 74, '03/01/2019', 6, '6', 'Support to Infra Team \r\nInfra App - Create Vendor form modifications (Done)\"', NULL, '2019-03-01 18:38:37', '2019-03-01 18:38:37'),
(188, 72, '03/02/2019', 5, '3', 'Call with users', NULL, '2019-03-02 18:30:58', '2019-03-02 18:30:58'),
(189, 72, '03/02/2019', 5, '1', 'Support on AIT', NULL, '2019-03-02 18:30:58', '2019-03-02 18:30:58'),
(190, 72, '03/02/2019', 5, '1', 'Support on AMR', NULL, '2019-03-02 18:30:58', '2019-03-02 18:30:58'),
(191, 72, '03/02/2019', 5, '2', 'Support', NULL, '2019-03-02 18:30:58', '2019-03-02 18:30:58'),
(192, 72, '03/02/2019', 2, '1', 'Support', NULL, '2019-03-02 18:30:58', '2019-03-02 18:30:58'),
(193, 75, '03/02/2019', 17, '8', 'show Product Review model in Admin Pannel[done]\r\n- Add,Update,Delete blog System on admin pannel[Done]\r\n - Change Category into Sarees on header in Wesite[done]\r\n -  Add Bags on header in website[done];\r\n - make new arrival in home page dynamic[done]', NULL, '2019-03-02 18:31:42', '2019-03-02 18:31:42'),
(194, 75, '03/02/2019', 17, '8', 'show Product Review model in Admin Pannel[done]\r\n- Add,Update,Delete blog System on admin pannel[Done]\r\n - Change Category into Sarees on header in Wesite[done]\r\n -  Add Bags on header in website[done];\r\n - make new arrival in home page dynamic[done]', NULL, '2019-03-02 18:31:42', '2019-03-02 18:31:42'),
(195, 79, '03/02/2019', 1, '8', '-Implement  Teacher Time Table Layout In Student Application\r\n--Implement Custom Spinner in Student Application And Show  Data(Done)', NULL, '2019-03-02 18:31:49', '2019-03-02 18:31:49'),
(196, 69, '03/02/2019', 19, '1', 'Prepared Inventory Management PPT', NULL, '2019-03-02 18:36:29', '2019-03-02 18:36:29'),
(197, 69, '03/02/2019', 3, '1', 'Support on ACME\r\nWorked on Convert FSR Code', NULL, '2019-03-02 18:36:29', '2019-03-02 18:36:29'),
(198, 69, '03/02/2019', 5, '1', 'Support on SAG\r\nSupport on AIT', NULL, '2019-03-02 18:36:29', '2019-03-02 18:36:29'),
(199, 69, '03/02/2019', 11, '5', 'Worked on Drone Application\r\n- Create Page for upload apk (DONE)\r\n- Add table for apk in database (DONE)\r\n- Testing upload apk module\r\n- Correction in site images api get permission to upload->apk->site images folder', NULL, '2019-03-02 18:36:29', '2019-03-02 18:36:29'),
(200, 76, '03/02/2019', 17, '8', '-edit of product\r\n-implemented checkbox and uploaded images\r\n-uploaded contents on about us.', NULL, '2019-03-02 18:37:56', '2019-03-02 18:37:56'),
(208, 79, '03/04/2019', 1, '8', '-Teacher Time Table  in Student \r\n     Application(Done)\r\n  -Hit API in Teacher Time Table(Done)\r\n  -Dashboard in Student \r\n      Application(Working)', NULL, '2019-03-04 18:31:54', '2019-03-04 18:31:54'),
(209, 72, '03/04/2019', 3, '4', 'Worked on ACME Attendance\r\n1. add mock location (working)\r\n2. get all application details which is installed in mobile then send to server(working)', NULL, '2019-03-04 18:31:54', '2019-03-04 18:31:54'),
(210, 72, '03/04/2019', 2, '1', 'Support on Saathi', NULL, '2019-03-04 18:31:54', '2019-03-04 18:31:54'),
(211, 72, '03/04/2019', 5, '1', 'Support on AIT', NULL, '2019-03-04 18:31:54', '2019-03-04 18:31:54'),
(212, 72, '03/04/2019', 5, '1', 'Support on AMR', NULL, '2019-03-04 18:31:54', '2019-03-04 18:31:54'),
(213, 72, '03/04/2019', 5, '1', 'Support on SAG', NULL, '2019-03-04 18:31:54', '2019-03-04 18:31:54'),
(214, 69, '03/04/2019', 19, '2', 'Support on SAG\r\nSupport on AIT\r\nSupport on Saahaj\r\nPrepare Inventory Cost Estimation sheet \r\nCall with Anupam', NULL, '2019-03-04 18:38:26', '2019-03-04 18:38:26'),
(215, 69, '03/04/2019', 12, '2', 'Create API for save all application details of mobile(ACME Attendance) - Add table for app_details in database\r\nand Support', NULL, '2019-03-04 18:38:26', '2019-03-04 18:38:26'),
(216, 69, '03/04/2019', 3, '4', 'Correction in Acme PDF generation  Code (ACME ESR)', NULL, '2019-03-04 18:38:26', '2019-03-04 18:38:26'),
(217, 71, '03/05/2019', 1, '1', 'Support Ayush on BIPE-Student', NULL, '2019-03-05 18:29:54', '2019-03-05 18:29:54'),
(218, 71, '03/05/2019', 11, '5', '- Testing Sync Site Images On live server (Done)\r\n- R & D on multiple size image can be sync option by user (Working)', NULL, '2019-03-05 18:29:54', '2019-03-05 18:29:54'),
(219, 71, '03/05/2019', 15, '2', '- Support Saahaj (Call to Saahaj Users) (Done)', NULL, '2019-03-05 18:29:54', '2019-03-05 18:29:54'),
(220, 72, '03/05/2019', 12, '3', '1. get all application details which is installed in mobile then send to server(done)\r\n 2. add mock location (done)', NULL, '2019-03-05 18:30:25', '2019-03-05 18:30:25'),
(221, 72, '03/05/2019', 2, '30min', 'Support on Saathi', NULL, '2019-03-05 18:30:25', '2019-03-05 18:30:25'),
(222, 72, '03/05/2019', 5, '30min', 'Support on AIT', NULL, '2019-03-05 18:30:25', '2019-03-05 18:30:25'),
(223, 72, '03/05/2019', 5, '1', 'Support on AMR', NULL, '2019-03-05 18:30:25', '2019-03-05 18:30:25'),
(224, 72, '03/05/2019', 5, '3', '1.Support on SAG\r\n2.Call with SAG users', NULL, '2019-03-05 18:30:25', '2019-03-05 18:30:25'),
(225, 79, '03/05/2019', 1, '8', '- Splash Screen in Student Application(Done)\r\n  -Login Activity  in Student Application(Done)\r\n -Hit API  Login Activity in Student Application(Working)', NULL, '2019-03-05 18:31:46', '2019-03-05 18:31:46'),
(226, 69, '03/05/2019', 15, '1', 'Support on Saahaj (Testing of App and share updated apk)', NULL, '2019-03-05 18:34:34', '2019-03-05 18:34:34'),
(227, 69, '03/05/2019', 5, '2.5', 'Support on SAG\r\n- Call to Users and clear Id, map district data\r\nSupport on AIT', NULL, '2019-03-05 18:34:34', '2019-03-05 18:34:34'),
(228, 69, '03/05/2019', 11, '4', 'Worked on Acme Drone\r\n- Create Master for Sub area\'s\r\n- Create table of sub area\r\n- Call with sir \r\n(Discussion on Image Resolution and size and area data format)', NULL, '2019-03-05 18:34:34', '2019-03-05 18:34:34'),
(229, 69, '03/05/2019', 3, '0.5', 'Support on User App Details', NULL, '2019-03-05 18:34:34', '2019-03-05 18:34:34'),
(230, 75, '03/05/2019', 17, '8', 'EOD:\r\nWorked On Weavenest Website\r\n - add short and detail description of blog on admin panel[done]\r\n - make blog make dynamic[done]\r\n - make view blog page dynamic[done]', NULL, '2019-03-05 18:34:57', '2019-03-05 18:34:57'),
(231, 76, '03/05/2019', 17, '8', 'add,update and delete on bag module.[done]\r\n-edit on blog-list.[done]', NULL, '2019-03-05 18:35:52', '2019-03-05 18:35:52'),
(232, 75, '03/06/2019', 17, '8', '-add-testimonial on website[done]\r\n-add  testimonials on admin pannel[done]\r\n- add blogs on the website [done]', NULL, '2019-03-06 18:31:15', '2019-03-06 18:31:15'),
(233, 76, '03/06/2019', 17, '8', '18:34\r\nworked on weavenest:\r\n-changes on blog page(done)\r\n-add,update and delete on testimonial pages.(done)', NULL, '2019-03-06 18:38:21', '2019-03-06 18:38:21'),
(234, 79, '03/06/2019', 1, '8', '-Hit API in Login Activity(Done)\r\n-Tree Structure in Teacher Time Table(done)', NULL, '2019-03-06 18:39:56', '2019-03-06 18:39:56'),
(235, 74, '03/06/2019', 6, '8', 'Support to Aniket and Shivani in Infra Office\r\nOffice Expense (data saving problem resolved) (Done)\r\nLogin Page validation and login problem issue resolved (Done)\r\nSite Expense (view and data saving) (Done)\r\nSite Allocation view (Done) , back-end (Working)', NULL, '2019-03-06 18:42:29', '2019-03-06 18:42:29'),
(236, 72, '03/06/2019', 12, '2', 'Add voice command in some module', NULL, '2019-03-06 18:42:36', '2019-03-06 18:42:36'),
(237, 72, '03/06/2019', 2, '1', 'Support on Saathi', NULL, '2019-03-06 18:42:36', '2019-03-06 18:42:36'),
(238, 72, '03/06/2019', 5, '1', 'Support on AIT', NULL, '2019-03-06 18:42:36', '2019-03-06 18:42:36'),
(239, 72, '03/06/2019', 5, '1', 'Support on AMR', NULL, '2019-03-06 18:42:36', '2019-03-06 18:42:36'),
(240, 72, '03/06/2019', 5, '3', 'Support on SAG', NULL, '2019-03-06 18:42:36', '2019-03-06 18:42:36'),
(241, 71, '03/07/2019', 15, '8', 'Worked On Saahaj :\r\n- resolve issues in application (Working)\r\n- support users to solve the problem in app (Done)', NULL, '2019-03-07 18:27:24', '2019-03-07 18:27:24'),
(242, 75, '03/07/2019', 17, '8', 'EOD:\r\n Worked on Weavenest\r\n- fix bugs on the layout of the aboutus page[done]\r\n- change home page banner[done]\r\n- change mobile no and email id through out the website[done]\r\n- change social media links[done]', NULL, '2019-03-07 18:33:34', '2019-03-07 18:33:34'),
(243, 79, '03/07/2019', 12, '1', 'Worked On ACME\r\n-Build Attendance Application', NULL, '2019-03-07 18:35:08', '2019-03-07 18:35:08'),
(244, 79, '03/07/2019', 1, '7', 'Worked on Student Application\r\n  -Tree Structure in Teacher Time Table(Working)\r\n  -Show Data in Teacher Time Table(Done)', NULL, '2019-03-07 18:35:08', '2019-03-07 18:35:08'),
(245, 76, '03/07/2019', 17, '8', '-changes on product module(done)\r\n-changes on bag module(done)', NULL, '2019-03-07 18:36:37', '2019-03-07 18:36:37'),
(246, 79, '03/08/2019', 1, '8', 'Dashboard  Layout in Student Application', NULL, '2019-03-08 18:33:19', '2019-03-08 18:33:19'),
(247, 72, '03/09/2019', 2, '1', 'Support on Saathi', NULL, '2019-03-09 18:30:07', '2019-03-09 18:30:07'),
(248, 72, '03/09/2019', 5, '1', 'Support on AMR', NULL, '2019-03-09 18:30:07', '2019-03-09 18:30:07'),
(249, 72, '03/09/2019', 5, '1', 'Support on AIT', NULL, '2019-03-09 18:30:07', '2019-03-09 18:30:07'),
(250, 72, '03/09/2019', 5, '2', 'Support on SAG', NULL, '2019-03-09 18:30:07', '2019-03-09 18:30:07'),
(251, 72, '03/09/2019', 5, '3', 'Worked on SAG\r\n 1. Minor changes in Layout\r\n 2. Sync solved (village no more needed)\r\n 3. Application upload on Play Store', NULL, '2019-03-09 18:30:07', '2019-03-09 18:30:07'),
(252, 79, '03/09/2019', 1, '8', '-Dashboard Layout()Done)\r\n-Show Data in Current Lecture And Next Lecture(Working)', NULL, '2019-03-09 18:32:26', '2019-03-09 18:32:26'),
(253, 71, '03/09/2019', 19, '6', 'Worked On Student Application :\r\n- show tree structure wise data (DONE)\r\n- support Ayush', NULL, '2019-03-09 18:34:44', '2019-03-09 18:34:44'),
(254, 71, '03/09/2019', 2, '2', '- resolve issues in application', NULL, '2019-03-09 18:34:44', '2019-03-09 18:34:44'),
(255, 74, '03/09/2019', 6, '8', 'Site Allocation\r\nMaterial Supplier master list and add controller method\r\nSite Expense View \r\nSupport and work flow information to infra guys', NULL, '2019-03-09 18:37:38', '2019-03-09 18:37:38'),
(256, 72, '03/11/2019', 12, '2', '1. check mock location', NULL, '2019-03-11 18:36:00', '2019-03-11 18:36:00'),
(257, 72, '03/11/2019', 2, '2', 'Support on Saathi', NULL, '2019-03-11 18:36:00', '2019-03-11 18:36:00'),
(258, 72, '03/11/2019', 5, '2', 'Support on SAG', NULL, '2019-03-11 18:36:00', '2019-03-11 18:36:00'),
(259, 72, '03/11/2019', 5, '1', 'Support on AIT', NULL, '2019-03-11 18:36:00', '2019-03-11 18:36:00'),
(260, 72, '03/11/2019', 5, '1', 'Support on AMR', NULL, '2019-03-11 18:36:00', '2019-03-11 18:36:00'),
(261, 79, '03/11/2019', 19, '8', '-Dynamic Show Data in Current Lecture And Next Lecture(Done).', NULL, '2019-03-11 18:36:25', '2019-03-11 18:36:25'),
(262, 71, '03/11/2019', 11, '6', '- save sub-area data to local at login (Done)\r\n- map sub area to area in drop down list in apm module (Done)\r\n- map sub area to area in drop down list in generic module (Done)\r\n- save form data of generic or apm (Done)\r\n- set drop down list of image size ratio to original to be sync (Done)\r\n- send additional data with image (Done)', NULL, '2019-03-11 18:40:59', '2019-03-11 18:40:59'),
(263, 71, '03/11/2019', 19, '2', 'Support Ayush in Student Application', NULL, '2019-03-11 18:40:59', '2019-03-11 18:40:59'),
(264, 74, '03/11/2019', 6, '8', 'Validations on allocate site form\r\nValidation on site expense form\r\nMaster for material supplier', NULL, '2019-03-11 18:41:28', '2019-03-11 18:41:28'),
(265, 71, '03/12/2019', 19, '2', 'Support Ayush on Student Application', NULL, '2019-03-12 18:24:14', '2019-03-12 18:24:14'),
(266, 71, '03/12/2019', 11, '3', '- Image sync with different sizes to server (Working)', NULL, '2019-03-12 18:24:14', '2019-03-12 18:24:14'),
(267, 71, '03/12/2019', 1, '1', 'Worked On BIPE-VMS :\r\n- make a build and testing', NULL, '2019-03-12 18:24:14', '2019-03-12 18:24:14'),
(268, 71, '03/12/2019', 15, '2', '- R & D on track issue', NULL, '2019-03-12 18:24:14', '2019-03-12 18:24:14'),
(269, 72, '03/12/2019', 12, '4', '1. detect mock location(done)\r\n2. operation perform on fake GPS(working)', NULL, '2019-03-12 18:26:26', '2019-03-12 18:26:26'),
(270, 72, '03/12/2019', 2, '1', 'Support on Saathi', NULL, '2019-03-12 18:26:26', '2019-03-12 18:26:26'),
(271, 72, '03/12/2019', 5, '1', 'Support on AMR', NULL, '2019-03-12 18:26:26', '2019-03-12 18:26:26'),
(272, 72, '03/12/2019', 5, '1', 'Support on AIT', NULL, '2019-03-12 18:26:26', '2019-03-12 18:26:26'),
(273, 72, '03/12/2019', 5, '1', 'Support on SAG', NULL, '2019-03-12 18:26:26', '2019-03-12 18:26:26'),
(274, 79, '03/12/2019', 19, '6', '- Show Current Lecture Period  in Current Lecture and Next Lecture Module', NULL, '2019-03-12 18:29:53', '2019-03-12 18:29:53'),
(275, 79, '03/13/2019', 19, '8', '- Show Current  Lecture Period in Current Lecture and Next Lecture Module(Working)', NULL, '2019-03-13 18:33:23', '2019-03-13 18:33:23'),
(276, 71, '03/13/2019', 19, '1', 'Support Ayush in Student Application', NULL, '2019-03-13 18:33:28', '2019-03-13 18:33:28'),
(277, 71, '03/13/2019', 11, '7', '- change service in application for image sync (Done)\r\n- filter out specific size image in the image sync (Working)', NULL, '2019-03-13 18:33:28', '2019-03-13 18:33:28'),
(278, 72, '03/14/2019', 12, '4', '1. operation perform on fake GPS\r\n 2. show circle id and login id in dashboard screen\r\n 3. show  fake gps status at dashboard screen', NULL, '2019-03-14 18:30:27', '2019-03-14 18:30:27'),
(279, 72, '03/14/2019', 2, '1', 'Support on Saathi', NULL, '2019-03-14 18:30:28', '2019-03-14 18:30:28'),
(280, 72, '03/14/2019', 5, '1', 'Support on AIT', NULL, '2019-03-14 18:30:28', '2019-03-14 18:30:28'),
(281, 72, '03/14/2019', 5, '1', 'Support on AMR', NULL, '2019-03-14 18:30:28', '2019-03-14 18:30:28'),
(282, 72, '03/14/2019', 5, '1', 'Support on SAG', NULL, '2019-03-14 18:30:28', '2019-03-14 18:30:28'),
(283, 79, '03/14/2019', 19, '8', '- Show Current Lecture Period in Current Lecture Module(Working)\r\n -Log Out in Dashboard Layout(Done)', NULL, '2019-03-14 18:31:31', '2019-03-14 18:31:31'),
(284, 71, '03/14/2019', 2, '1', 'Worked on VanSales :\r\n  - Change base url of application and build apk (Done)\r\n  - Resolving issues crash on Distribution module (Done)', NULL, '2019-03-14 18:32:55', '2019-03-14 18:32:55'),
(285, 71, '03/14/2019', 11, '2', '- filter out specific size image in the image sync (Working)', NULL, '2019-03-14 18:32:55', '2019-03-14 18:32:55'),
(286, 71, '03/14/2019', 15, '4', '(Resolve Track Data Issue) :\r\n  - Change backgorund service of track user data to Job Scheduler\r\n  - Change backgorund service of track user data to Foreground Service', NULL, '2019-03-14 18:32:55', '2019-03-14 18:32:55'),
(287, 71, '03/14/2019', 19, '1', 'Support Ayush in Student Application', NULL, '2019-03-14 18:32:55', '2019-03-14 18:32:55'),
(288, 75, '03/15/2019', 17, '4', 'worked on the admin login module in admin pannel', NULL, '2019-03-15 18:31:19', '2019-03-15 18:31:19'),
(289, 72, '03/15/2019', 19, '8', 'Support on SAG\r\nSupport on AIT\r\nSupport on Saathi\r\nSupport on AMR\r\nWorked on ACME Attendance\r\n- mock location check ---new format(working)', NULL, '2019-03-15 18:34:54', '2019-03-15 18:34:54'),
(290, 79, '03/15/2019', 19, '8', '-Attendance Layout in Student Application\r\n-Show Data in Current Lecture Module', NULL, '2019-03-15 18:35:18', '2019-03-15 18:35:18'),
(291, 71, '03/15/2019', 19, '2', 'Support Ayush On Student Application', NULL, '2019-03-15 18:38:20', '2019-03-15 18:38:20'),
(292, 71, '03/15/2019', 11, '4', 'Worked On Drone Application :\r\n  - sync image at multiple resolution (Done)\r\n  - sync image to selected specific define resolution options by a user (Working)', NULL, '2019-03-15 18:38:20', '2019-03-15 18:38:20'),
(293, 71, '03/15/2019', 2, '2', 'Worked On VanSales :\r\n  - discuss issue in application with ajay sir (Done)\r\n  - resolve issue of distribution sync details (Done)\r\n  - auto delete db at the time of login (Done)', NULL, '2019-03-15 18:38:20', '2019-03-15 18:38:20'),
(294, 76, '03/15/2019', 19, '8', '-downloaded theme and implemented on laravel', NULL, '2019-03-15 18:39:56', '2019-03-15 18:39:56'),
(295, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:44:53', '2019-03-15 18:44:53'),
(296, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:44:53', '2019-03-15 18:44:53'),
(297, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:44:53', '2019-03-15 18:44:53'),
(298, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:44:56', '2019-03-15 18:44:56'),
(299, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:44:56', '2019-03-15 18:44:56'),
(300, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:44:56', '2019-03-15 18:44:56'),
(301, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:00', '2019-03-15 18:45:00'),
(302, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:00', '2019-03-15 18:45:00'),
(303, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:00', '2019-03-15 18:45:00'),
(304, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:00', '2019-03-15 18:45:00'),
(305, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:00', '2019-03-15 18:45:00'),
(306, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:00', '2019-03-15 18:45:00'),
(307, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:01', '2019-03-15 18:45:01'),
(308, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:01', '2019-03-15 18:45:01'),
(309, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:01', '2019-03-15 18:45:01'),
(310, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:03', '2019-03-15 18:45:03'),
(311, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:03', '2019-03-15 18:45:03'),
(312, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:03', '2019-03-15 18:45:03'),
(313, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:03', '2019-03-15 18:45:03'),
(314, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:03', '2019-03-15 18:45:03'),
(315, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:03', '2019-03-15 18:45:03'),
(316, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(317, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(318, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(319, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(320, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(321, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(322, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(323, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(324, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(325, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(326, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04');
INSERT INTO `eods` (`id`, `user_id`, `date_of_eod`, `project_id`, `hours_spent`, `task`, `comment`, `created_at`, `updated_at`) VALUES
(327, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:04', '2019-03-15 18:45:04'),
(328, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:08', '2019-03-15 18:45:08'),
(329, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:08', '2019-03-15 18:45:08'),
(330, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:08', '2019-03-15 18:45:08'),
(331, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(332, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(333, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(334, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(335, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(336, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(337, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(338, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(339, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(340, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(341, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(342, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:09', '2019-03-15 18:45:09'),
(343, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(344, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(345, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(346, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(347, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(348, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(349, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(350, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(351, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(352, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(353, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(354, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(355, 81, '03/15/2019', 19, '3', 'checked site supervisors  expense reports', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(356, 81, '03/15/2019', 19, '2', 'worked on excel  master sheet given by richa ma\'am', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(357, 81, '03/15/2019', 19, '1', 'updated data on excel given by vipul sir', NULL, '2019-03-15 18:45:12', '2019-03-15 18:45:12'),
(358, 81, '03/16/2019', 19, '2', 'cdcvvdfv', NULL, '2019-03-16 11:18:01', '2019-03-16 11:18:01'),
(359, 81, '03/16/2019', 19, '1', 'c sd', NULL, '2019-03-16 11:18:01', '2019-03-16 11:18:01'),
(360, 81, '03/16/2019', 19, '1', 'prepare excel', NULL, '2019-03-16 11:57:05', '2019-03-16 11:57:05'),
(361, 71, '03/16/2019', 2, '8', 'Worked On Saathi and VanSales Application :\r\n- code merging (Working)', NULL, '2019-03-16 18:24:42', '2019-03-16 18:24:42'),
(362, 75, '03/16/2019', 17, '8', 'EOD:\r\nWorked on Taskmonitor\r\n   - testing save collection detail api(done)\r\n worked on weavenest\r\n   - make admin login  in admin panel (partially done)', NULL, '2019-03-16 18:27:05', '2019-03-16 18:27:05'),
(363, 72, '03/16/2019', 12, '4', '1. operation perform on fake GPS(done)\r\n 2. mock location check (new format)(done)\r\n 3. prepare ACME Attendance excel sheet(done)', NULL, '2019-03-16 18:30:13', '2019-03-16 18:30:13'),
(364, 72, '03/16/2019', 2, '2', '1. Review Code\r\n 2. Test APK and resolve some issues\r\n 3. Share code with MOHIT', NULL, '2019-03-16 18:30:13', '2019-03-16 18:30:13'),
(365, 72, '03/16/2019', 5, '30 min', 'Support on AIT', NULL, '2019-03-16 18:30:13', '2019-03-16 18:30:13'),
(366, 72, '03/16/2019', 5, '30 min', 'Support on AMR', NULL, '2019-03-16 18:30:13', '2019-03-16 18:30:13'),
(367, 72, '03/16/2019', 5, '1', 'Support on SAG', NULL, '2019-03-16 18:30:13', '2019-03-16 18:30:13'),
(368, 79, '03/16/2019', 19, '8', 'Worked On Student Application\r\n - Show Dynamic Calendar  in Attendance Module', NULL, '2019-03-16 18:31:51', '2019-03-16 18:31:51'),
(369, 74, '03/16/2019', 6, '8', 'Site Importation (Deployment , Matrix, and Location Sheet)\r\nResolved the problem (Site Allocation form submission and add nature of work)\r\nSupport to Infra guys', NULL, '2019-03-16 18:34:17', '2019-03-16 18:34:17'),
(370, 81, '03/16/2019', 19, '1', 'searched information about  TIO editors', NULL, '2019-03-16 19:14:05', '2019-03-16 19:14:05'),
(371, 81, '03/16/2019', 19, '2', 'prepare emplyees detail excel sheet', NULL, '2019-03-16 19:14:05', '2019-03-16 19:14:05'),
(372, 81, '03/16/2019', 19, '2', 'worked on excel expense  mastersheet', NULL, '2019-03-16 19:14:05', '2019-03-16 19:14:05'),
(373, 71, '03/18/2019', 2, '9', '- resolving issue of track user data (Working)', NULL, '2019-03-18 18:20:32', '2019-03-18 18:20:32'),
(374, 72, '03/18/2019', 12, '2', 'Support on ACME Attendance', NULL, '2019-03-18 18:31:06', '2019-03-18 18:31:06'),
(375, 72, '03/18/2019', 5, '1', 'Support on AIT', NULL, '2019-03-18 18:31:06', '2019-03-18 18:31:06'),
(376, 72, '03/18/2019', 5, '1', 'Support on AMR', NULL, '2019-03-18 18:31:06', '2019-03-18 18:31:06'),
(377, 72, '03/18/2019', 5, '4', 'Support on SAG', NULL, '2019-03-18 18:31:06', '2019-03-18 18:31:06'),
(378, 79, '03/18/2019', 19, '8', 'Worked on Student Application\r\n - Show Current  Lecture Period in Current Lecture Module (Done)\r\n- Show Next Lecture Period in Next Lecture Module(Done)\r\n-Show Dynamic Calendar  in Attendance Module (Working)', NULL, '2019-03-18 18:32:31', '2019-03-18 18:32:31'),
(379, 76, '03/18/2019', 19, '8', 'implemented pages on laravel(home,about,events,blogs,gallery,speaker,contact)[done]', NULL, '2019-03-18 18:44:37', '2019-03-18 18:44:37'),
(380, 74, '03/23/2019', 6, '6', 'Detailed attendance view (IN, OUT time, working hours) - working', NULL, '2019-03-23 18:34:44', '2019-03-23 18:34:44'),
(381, 74, '03/23/2019', 19, '2', 'SRT - Some changes and validations with the help of Raghvendra Sir', NULL, '2019-03-23 18:34:44', '2019-03-23 18:34:44'),
(382, 71, '03/23/2019', 11, '8', 'Sync images according to user ratio (Done)\r\nTesting (Done)', NULL, '2019-03-23 18:37:29', '2019-03-23 18:37:29'),
(383, 71, '03/25/2019', 2, '4', 'code merge of Saathi and VanSales application', NULL, '2019-03-25 18:17:00', '2019-03-25 18:17:00'),
(384, 71, '03/25/2019', 11, '4', '- testing (Done)\r\n- resolve issue at the time of change resolution (Done)\r\n- crash at the of all images synced (Done)', NULL, '2019-03-25 18:17:00', '2019-03-25 18:17:00'),
(385, 75, '03/25/2019', 17, '8', 'EOD:\r\n- Implementing theme on laravel(working)\r\n- worked on the FB login of Weavenest(working)', NULL, '2019-03-25 18:18:07', '2019-03-25 18:18:07'),
(386, 79, '03/25/2019', 19, '8', 'Worked on Student Application\r\n  -Show Dynamic Calendar  in Attendance Module(Working) .', NULL, '2019-03-25 18:24:20', '2019-03-25 18:24:20'),
(387, 76, '03/25/2019', 19, '8', 'templating of theme on laravel(done)', NULL, '2019-03-25 18:24:49', '2019-03-25 18:24:49'),
(388, 74, '03/25/2019', 6, '8', 'Office Attendance Detail View\r\nValidations and checks\r\nDemo in Infra office to Vipul Sir', NULL, '2019-03-25 18:32:50', '2019-03-25 18:32:50'),
(389, 71, '03/26/2019', 19, '1', 'Support Ayush on Student Application', NULL, '2019-03-26 18:27:04', '2019-03-26 18:27:04'),
(390, 71, '03/26/2019', 2, '7', 'Worked On Saathi and VanSales Application :\r\n- code merge (Working)', NULL, '2019-03-26 18:27:04', '2019-03-26 18:27:04'),
(391, 79, '03/26/2019', 19, '8', 'Worked On Student Application\r\n- Attendance Module', NULL, '2019-03-26 18:39:51', '2019-03-26 18:39:51'),
(392, 71, '03/27/2019', 2, '8', 'Worked On Saathi and VanSales Application :\r\n- code merge (Working)', NULL, '2019-03-27 18:25:18', '2019-03-27 18:25:18'),
(393, 75, '03/27/2019', 17, '8', 'Worked on Sai \r\n- solve bugs of login(Working);\r\nWorked on weavenest\r\n- worked on the home page layout of the website(done)', NULL, '2019-03-27 18:30:00', '2019-03-27 18:30:00'),
(394, 76, '03/27/2019', 19, '8', 'worked on eventplanner:\r\n-setup admin panel theme (done)\r\n-manage dynamin slider(add,edit,update,delete) in admin panel(done)\r\n-manage events(working)', NULL, '2019-03-27 18:30:41', '2019-03-27 18:30:41'),
(395, 79, '03/27/2019', 19, '8', 'Worked On Student Application\r\n-Show Static Calendar  in Attendance Module(Done) \r\n - Show Dynamic Calendar  (Working)', NULL, '2019-03-27 18:30:45', '2019-03-27 18:30:45'),
(396, 74, '03/27/2019', 6, '8', '- Duplicate Data validation in adding vendor\r\n- Duplicate Data validation in edit vendor \r\n- Validation (compulsory fields) correction in edit vendor \r\n- Data correction in database', NULL, '2019-03-27 18:32:38', '2019-03-27 18:32:38'),
(397, 71, '03/28/2019', 11, '3', '- make excel sheet for drone company (Done)\r\n- make ppt of Salon drone images details with tracking image', NULL, '2019-03-28 18:16:19', '2019-03-28 18:16:19'),
(398, 71, '03/28/2019', 2, '5', 'Worked On Rufil :\r\n- change layout (Done)\r\n- change logo (Done)', NULL, '2019-03-28 18:16:19', '2019-03-28 18:16:19'),
(399, 75, '03/28/2019', 19, '8', 'EOD :\r\nWorked on sai :\r\n- setup sai software in zend localhost(done)\r\n- solve login php version problem(done)\r\n- send notification issue(working)', NULL, '2019-03-28 18:22:00', '2019-03-28 18:22:00'),
(400, 75, '03/28/2019', 19, '8', 'EOD :\r\nWorked on sai :\r\n- setup sai software in zend localhost(done)\r\n- solve login php version problem(done)\r\n- send notification issue(working)', NULL, '2019-03-28 18:22:00', '2019-03-28 18:22:00'),
(401, 76, '03/28/2019', 19, '8', 'worked on eventplanner:\r\n-manage events(done)', NULL, '2019-03-28 18:25:22', '2019-03-28 18:25:22'),
(402, 72, '03/28/2019', 19, '30min', 'Worked on Task APP\r\n 1. Do some changes and generate application build', NULL, '2019-03-28 18:27:28', '2019-03-28 18:27:28'),
(403, 72, '03/28/2019', 3, '1', 'Support on ACME ESR\r\n1. app data not found and show some SQL exception', NULL, '2019-03-28 18:27:28', '2019-03-28 18:27:28'),
(404, 72, '03/28/2019', 12, '4', 'Worked on ACME Attendance\r\n 1. Hit API and send email to client when user uses Fake GPS Application(working)', NULL, '2019-03-28 18:27:28', '2019-03-28 18:27:28'),
(405, 72, '03/28/2019', 5, '30min', 'Support on AIT', NULL, '2019-03-28 18:27:28', '2019-03-28 18:27:28'),
(406, 72, '03/28/2019', 5, '2', 'Support on SAG\r\nWorked on SAG \r\n 1. worked on Sync issues\r\n 2. update application on play store', NULL, '2019-03-28 18:27:28', '2019-03-28 18:27:28'),
(407, 79, '03/28/2019', 19, '8', 'Worked On Student Application\r\n - Show Dynamic Calendar Attendance Module  (Working)', NULL, '2019-03-28 18:30:58', '2019-03-28 18:30:58'),
(408, 74, '03/28/2019', 6, '8', '- Data duplicate validation in vendor data while adding and editing  (Done)\r\n- Visited Infra office with meeting with Vipul Sir', NULL, '2019-03-28 18:32:40', '2019-03-28 18:32:40'),
(409, 69, '03/28/2019', 19, '1', 'Support on M3M Task App\r\nSupport on Acme Drone\r\n- Discussion with Shubham', NULL, '2019-03-28 18:34:58', '2019-03-28 18:34:58'),
(410, 69, '03/28/2019', 5, '3', 'Support on SAG\r\n- Call with User and mapped Area of SUB001190 User \r\n\r\nSupport On AIT\r\n- check Data view', NULL, '2019-03-28 18:34:58', '2019-03-28 18:34:58'),
(411, 69, '03/28/2019', 3, '4', '- Call with Raj Sir\r\n- Resloved Issue of Get Job Api (Wrong Data Entry) [Done]\r\n- Create Api for send email when Mock Location on by User', NULL, '2019-03-28 18:34:58', '2019-03-28 18:34:58'),
(412, 76, '03/29/2019', 19, '8', 'worked on eventplanner:\r\n-login page for user and organiser(done)', NULL, '2019-03-29 18:27:03', '2019-03-29 18:27:03'),
(413, 71, '03/29/2019', 19, '1', 'Support Ayush in Syllabus Module of Student Application (Done)', NULL, '2019-03-29 18:28:11', '2019-03-29 18:28:11'),
(414, 71, '03/29/2019', 2, '7', 'Worked On Saathi and VanSales Application :\r\n- code merge (distribution module) (Working)', NULL, '2019-03-29 18:28:11', '2019-03-29 18:28:11'),
(415, 75, '03/29/2019', 19, '8', 'EOD:\r\n- Worked on sai \r\n  - add  Course years of the student(done)\r\n  - add semester of every year of the student(done)\r\n  - increase and add fee of every semester(done)\r\n- Worked on AMR \r\n   - edit disease type(working)', NULL, '2019-03-29 18:33:21', '2019-03-29 18:33:21'),
(416, 74, '03/29/2019', 6, '8', 'Worked on Infra \r\n- Edit, Delete or update request from user side to upper level (Working)\r\n- Created table and changes in table for request (Done)\r\n- Support to Infra guys', NULL, '2019-03-29 18:41:33', '2019-03-29 18:41:33');

-- --------------------------------------------------------

--
-- Table structure for table `gps_data`
--

CREATE TABLE `gps_data` (
  `id` int(11) NOT NULL,
  `gps_string` text NOT NULL,
  `status` varchar(22) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `id` int(10) UNSIGNED NOT NULL,
  `month` int(11) NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`id`, `month`, `date`, `comments`, `category`, `created_at`, `updated_at`) VALUES
(1, 1, '01/01/2018', 'New Year', 'development', '2018-06-27 12:28:56', '2018-06-27 12:28:56'),
(2, 1, '01/26/2018', 'Repulic Day', 'development', '2018-06-27 12:35:16', '2018-06-27 12:35:16'),
(3, 2, '02/14/2018', 'Maha Shivratri', 'development', '2018-06-27 12:35:16', '2018-06-27 12:35:16'),
(4, 3, '02/03/2018', 'Holi', 'development', '2018-06-27 12:35:16', '2018-06-27 12:35:16'),
(5, 8, '08/15/2018', 'Independence Day', 'development', '2018-06-27 12:35:16', '2018-06-27 12:35:16'),
(6, 8, '08/26/2018', 'Raksha-Bandhan', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38'),
(7, 10, '10/02/2018', 'Gandhi Jayanti', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38'),
(8, 10, '10/19/2018', 'Dusshehra', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38'),
(9, 11, '11/07/2018', 'Deepawali', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38'),
(10, 11, '11/08/2018', 'Deepawali', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38'),
(11, 11, '11/09/2018', 'Deepawali', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38'),
(12, 6, '06/15/2018', 'Id-Ul-Fitar', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38'),
(13, 12, '12/25/2018', 'Christmas Day', 'development', '2018-06-27 12:41:38', '2018-06-27 12:41:38');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `leave_type_id` int(10) UNSIGNED NOT NULL,
  `date_from` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `days` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `is_approved` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`id`, `user_id`, `leave_type_id`, `date_from`, `date_to`, `days`, `contact_number`, `reason`, `is_approved`, `created_at`, `updated_at`) VALUES
(1, 76, 3, '07/19/2018', '07/19/2018', '1', '9984577914', 'Hi \r\n\r\nI’m emailing to inform you that I can’t make it to work tomorrow, (19/04/2018), as I am not well. I\'ll be available to answer emails if you need urgent help.\r\n\r\n\r\n\r\nThank you for understanding,', 1, '2018-07-18 18:25:15', '2018-07-18 18:35:51'),
(2, 77, 4, '02/18/2019', '02/19/2019', '2', '7081628885', 'Personal Work', 0, '2019-02-13 18:28:07', '2019-02-13 18:28:07');

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE `leave_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `leave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`id`, `leave_type`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Paid Leave', 'Paid Leave', '2017-12-26 18:16:40', '2018-01-30 08:47:24'),
(2, 'Unpaid Leave', 'Unpaid Leave', '2018-01-04 03:20:57', '2018-01-04 03:20:57'),
(3, 'Sick Leave', 'Sick Leave', '2018-01-09 22:10:46', '2018-01-09 22:10:46'),
(4, 'Casual Leave', 'Casual Leave', '2018-01-09 22:10:46', '2018-01-09 22:10:46'),
(5, 'Maternity Leave', 'Maternity Leave', '2018-01-09 22:11:19', '2018-01-09 22:11:19'),
(6, 'Paternity Leave', 'Paternity Leave', '2018-01-09 22:11:19', '2018-01-09 22:11:19'),
(7, 'medical leave', 'paid leave', '2018-01-23 05:54:47', '2018-01-25 07:42:38');

-- --------------------------------------------------------

--
-- Table structure for table `master_assets`
--

CREATE TABLE `master_assets` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_type_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `master_assets`
--

INSERT INTO `master_assets` (`id`, `asset_type_id`, `name`, `asset_code`, `created_at`, `updated_at`) VALUES
(3, 1, 'Desktop', 'DT', NULL, NULL),
(4, 1, 'Laptop', 'LP', NULL, NULL),
(5, 1, 'MacMini', 'MM', NULL, NULL),
(6, 1, 'iMac', 'IM', NULL, NULL),
(7, 1, 'Camera', 'CM', NULL, NULL),
(10, 1, 'Backup', 'BC', NULL, NULL),
(11, 1, 'Network ', 'NT', NULL, NULL),
(12, 1, 'Printer', 'PR', NULL, NULL),
(13, 2, 'Infra', 'IF', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_12_26_153621_create_roles_table', 2),
(4, '2017_12_26_171219_create_employee_personal_details_table', 3),
(5, '2017_12_26_171359_create_employee_cb_profiles_table', 3),
(6, '2017_12_26_171451_create_employee_previous_employments_table', 3),
(7, '2017_12_26_171546_create_employee_cb_appraisal_details_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `sender_id` int(10) UNSIGNED NOT NULL,
  `receiver_id` int(10) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `sender_id`, `receiver_id`, `title`, `message`, `is_read`, `created_at`, `updated_at`) VALUES
(25, 1, 68, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 14:32:45', '2018-07-18 14:32:45'),
(26, 1, 68, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 14:34:27', '2018-07-18 14:34:27'),
(27, 1, 68, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 14:41:18', '2018-07-18 14:41:18'),
(28, 1, 69, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 14:42:41', '2018-07-18 14:42:41'),
(29, 1, 69, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 14:49:10', '2018-07-18 14:49:10'),
(30, 1, 69, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 14:50:23', '2018-07-18 14:50:23'),
(31, 1, 70, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 14:55:56', '2018-07-18 18:15:57'),
(32, 1, 70, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 14:57:49', '2018-07-18 18:15:51'),
(33, 1, 71, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 15:05:45', '2018-07-18 15:05:45'),
(34, 1, 72, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:12:42', '2019-02-09 10:54:14'),
(35, 1, 73, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:19:15', '2019-02-12 18:28:54'),
(36, 1, 74, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:28:05', '2018-07-19 15:10:40'),
(37, 1, 75, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 15:32:19', '2018-07-18 15:32:19'),
(38, 1, 74, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:32:53', '2018-07-19 15:10:52'),
(39, 1, 76, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 15:36:07', '2018-07-18 15:36:07'),
(40, 1, 75, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2018-07-18 15:37:40', '2018-07-18 15:37:40'),
(41, 1, 77, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:43:49', '2018-07-18 17:20:13'),
(42, 1, 77, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:45:59', '2018-07-18 17:20:41'),
(43, 1, 77, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:47:42', '2018-07-18 16:58:11'),
(44, 1, 74, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2018-07-18 15:52:55', '2018-07-19 15:10:49'),
(45, 1, 72, 'Admin Assigned You Team Leader ( Raghvendra Pratap)', 'Admin Assigned You Team Leader ( Raghvendra Pratap)', 1, '2018-07-18 17:17:53', '2019-02-09 10:54:11'),
(46, 1, 77, 'Admin Assigned You Team Member ( Satyam)', 'Admin Assigned You Team Member ( Satyam)', 1, '2018-07-18 17:17:53', '2018-07-18 17:20:46'),
(47, 1, 70, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 1, '2018-07-18 17:18:34', '2018-07-18 18:15:40'),
(48, 1, 69, 'Admin Assigned You Team Member ( Puneet)', 'Admin Assigned You Team Member ( Puneet)', 0, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(49, 1, 71, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 0, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(50, 1, 69, 'Admin Assigned You Team Member ( Abhishek)', 'Admin Assigned You Team Member ( Abhishek)', 0, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(51, 1, 73, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 1, '2018-07-18 17:18:34', '2019-02-12 18:28:44'),
(52, 1, 69, 'Admin Assigned You Team Member ( Shailesh)', 'Admin Assigned You Team Member ( Shailesh)', 0, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(53, 1, 74, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 1, '2018-07-18 17:18:34', '2018-07-19 15:10:35'),
(54, 1, 69, 'Admin Assigned You Team Member ( Amit)', 'Admin Assigned You Team Member ( Amit)', 0, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(55, 1, 75, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 0, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(56, 1, 69, 'Admin Assigned You Team Member ( Annu)', 'Admin Assigned You Team Member ( Annu)', 0, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(57, 1, 76, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 0, '2018-07-18 17:18:46', '2018-07-18 17:18:46'),
(58, 1, 69, 'Admin Assigned You Team Member ( Adeeba)', 'Admin Assigned You Team Member ( Adeeba)', 0, '2018-07-18 17:18:46', '2018-07-18 17:18:46'),
(59, 1, 77, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 17:36:23', '2018-07-18 17:36:23'),
(60, 1, 77, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 17:39:00', '2018-07-18 17:39:00'),
(61, 1, 68, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:42:33', '2018-07-18 18:16:52'),
(62, 1, 69, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:44:07', '2018-07-18 17:47:54'),
(63, 1, 71, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 17:46:18', '2018-07-18 17:46:18'),
(64, 1, 73, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:49:13', '2019-02-12 18:28:33'),
(65, 1, 74, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:49:55', '2018-07-19 15:10:46'),
(66, 1, 71, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 17:50:27', '2018-07-18 17:50:27'),
(67, 1, 75, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 17:51:15', '2018-07-18 17:51:15'),
(68, 1, 70, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:52:37', '2018-07-18 18:15:32'),
(69, 1, 72, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:54:06', '2019-02-09 10:54:08'),
(70, 1, 72, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:55:25', '2019-02-09 10:54:04'),
(71, 1, 74, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:58:49', '2018-07-18 18:14:18'),
(72, 1, 75, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 17:59:22', '2018-07-18 18:17:04'),
(73, 1, 77, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 17:59:58', '2018-07-18 17:59:58'),
(74, 1, 76, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 18:03:18', '2018-07-18 18:03:18'),
(75, 1, 76, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 18:03:47', '2018-07-18 18:03:47'),
(76, 1, 76, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2018-07-18 18:04:27', '2018-07-18 18:04:27'),
(77, 1, 76, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2018-07-18 18:04:55', '2018-07-20 17:57:26'),
(78, 74, 1, 'Amit Chaurasiya Changed Password', 'Amit Chaurasiya Changed Password', 0, '2018-07-18 18:13:49', '2018-07-18 18:13:49'),
(79, 70, 1, 'Puneet Mishra Changed Password', 'Puneet Mishra Changed Password', 0, '2018-07-18 18:16:39', '2018-07-18 18:16:39'),
(80, 76, 1, 'Adeeba Khan Requested for Leave', 'Adeeba Khan Requested for Leave.<br><a href=\'http://hrms.pmmsapp.com/role/leave-listing?type=pending\' class=\'btn btn-primary\'>view</a>', 0, '2018-07-18 18:25:15', '2018-07-18 18:25:15'),
(81, 1, 76, 'Admin Accepted You leave request.', 'Admin Accepted You leave request.', 0, '2018-07-18 18:35:51', '2018-07-18 18:35:51'),
(82, 68, 74, 'IT Asset Manager Assigned You System DT001', 'IT Asset Manager Assigned You System DT001', 1, '2018-12-14 10:52:18', '2018-12-14 10:54:34'),
(83, 68, 1, 'IT Asset Manager Assigned System DT001 to Amit Chaurasiya', 'IT Asset Manager Assigned System DT001 to Amit Chaurasiya', 0, '2018-12-14 10:52:18', '2018-12-14 10:52:18'),
(84, 68, 74, 'IT Asset Manager Released Your System DT001', 'IT Asset Manager Released Your System DT001', 1, '2018-12-14 10:57:36', '2019-02-12 09:57:00'),
(85, 68, 1, 'IT Asset Manager Released System DT001 from Amit Chaurasiya', 'IT Asset Manager Released System DT001 from Amit Chaurasiya', 1, '2018-12-14 10:57:36', '2019-03-04 10:01:23'),
(86, 1, 70, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:09:24', '2019-02-09 10:09:24'),
(87, 1, 71, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:10:28', '2019-02-09 10:10:28'),
(88, 1, 69, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:10:31', '2019-02-09 10:10:31'),
(89, 1, 77, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:11:05', '2019-02-09 10:11:05'),
(90, 1, 75, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:13:15', '2019-02-09 10:13:15'),
(91, 1, 70, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:14:43', '2019-02-09 10:14:43'),
(92, 1, 69, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:14:48', '2019-02-09 10:14:48'),
(93, 1, 72, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2019-02-09 10:16:04', '2019-02-09 10:54:01'),
(94, 1, 71, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:16:59', '2019-02-09 10:16:59'),
(96, 75, 1, 'Saumya Gupta Requested For profile update.', 'Saumya Gupta Requested For profile update.<br><a href=\'http://hrms.pmmsapp.com/role/request/profile/75\' class=\'btn btn-primary\'>view</a>', 1, '2019-02-09 10:26:24', '2019-02-09 10:28:51'),
(97, 72, 1, 'Pramod yadav Requested For profile update.', 'Pramod yadav Requested For profile update.<br><a href=\'http://hrms.pmmsapp.com/role/request/profile/72\' class=\'btn btn-primary\'>view</a>', 1, '2019-02-09 10:27:05', '2019-03-04 10:17:41'),
(98, 1, 72, 'Admin Approved Your Profile change request.', 'Admin Approved Your Profile change request.', 1, '2019-02-09 10:28:15', '2019-02-09 10:53:57'),
(99, 1, 75, 'Admin Approved Your Profile change request.', 'Admin Approved Your Profile change request.', 0, '2019-02-09 10:28:18', '2019-02-09 10:28:18'),
(100, 72, 1, 'Pramod Kumar Yadav Changed Password', 'Pramod Kumar Yadav Changed Password', 1, '2019-02-09 10:30:22', '2019-03-04 10:01:20'),
(101, 1, 77, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 10:42:06', '2019-02-09 10:42:06'),
(102, 1, 71, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2019-02-09 11:08:28', '2019-02-09 11:08:28'),
(103, 1, 72, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2019-02-09 11:40:44', '2019-02-09 18:33:16'),
(104, 1, 72, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2019-02-09 11:41:43', '2019-02-09 18:33:13'),
(105, 1, 72, 'Admin Updated your Profile', 'Admin Updated your Profile', 1, '2019-02-09 11:43:06', '2019-02-09 18:33:10'),
(106, 1, 75, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2019-02-09 11:44:12', '2019-02-09 11:44:12'),
(107, 1, 75, 'Admin Updated your Profile', 'Admin Updated your Profile', 0, '2019-02-09 11:44:28', '2019-02-09 11:44:28'),
(108, 1, 77, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 0, '2019-02-09 12:00:42', '2019-02-09 12:00:42'),
(109, 1, 74, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2019-02-09 18:41:55', '2019-02-12 09:56:56'),
(110, 1, 72, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 1, '2019-02-09 18:45:27', '2019-02-19 11:47:05'),
(111, 1, 69, 'Admin Assigned You Team Member ( Pramod)', 'Admin Assigned You Team Member ( Pramod)', 0, '2019-02-09 18:45:27', '2019-02-09 18:45:27'),
(112, 1, 79, 'Admin Assigned You Team Leader ( Ajay)', 'Admin Assigned You Team Leader ( Ajay)', 0, '2019-02-09 18:45:27', '2019-02-09 18:45:27'),
(113, 1, 69, 'Admin Assigned You Team Member ( Ayush)', 'Admin Assigned You Team Member ( Ayush)', 1, '2019-02-09 18:45:27', '2019-02-11 18:29:58'),
(114, 74, 1, 'Amit Chaurasiya Requested For profile update.', 'Amit Chaurasiya Requested For profile update.<br><a href=\'http://hrms.pmmsapp.com/role/request/profile/74\' class=\'btn btn-primary\'>view</a>', 1, '2019-02-12 10:03:07', '2019-03-04 10:02:18'),
(115, 77, 1, 'Raghvendra Pratap Singh Requested for Leave', 'Raghvendra Pratap Singh Requested for Leave.<br><a href=\'http://hrms.pmmsapp.com/role/leave-listing?type=pending\' class=\'btn btn-primary\'>view</a>', 1, '2019-02-13 18:28:07', '2019-02-15 18:39:15'),
(116, 1, 77, 'Admin Assigned you a New Project.', 'Admin Assigned you a New Project.', 1, '2019-02-15 14:47:39', '2019-02-15 18:40:08'),
(117, 76, 1, 'Arpita upadhyay Requested For profile update.', 'Arpita upadhyay Requested For profile update.<br><a href=\'http://hrms.pmmsapp.com/role/request/profile/76\' class=\'btn btn-primary\'>view</a>', 1, '2019-02-26 18:34:46', '2019-03-04 10:01:14'),
(118, 1, 76, 'Admin Approved Your Profile change request.', 'Admin Approved Your Profile change request.', 0, '2019-03-04 10:00:55', '2019-03-04 10:00:55'),
(119, 1, 74, 'Admin Approved Your Profile change request.', 'Admin Approved Your Profile change request.', 1, '2019-03-04 10:01:05', '2019-03-23 10:21:05');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('ajay@logimetrix.me', '619681e5-5211-3e65-90e2-5e53f010ed33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_client_eod_receiver` int(11) NOT NULL DEFAULT '0',
  `project_comments` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_id`, `name`, `start_date`, `end_date`, `client_name`, `client_email`, `is_client_eod_receiver`, `project_comments`, `created_at`, `updated_at`) VALUES
(1, 'PROJECT001', 'BIPE', '06/14/2017', NULL, 'Mr. Praveen Rai', NULL, 0, 'College ERP System', '2018-07-18 17:25:15', '2018-07-18 17:25:15'),
(2, 'PROJECT002', 'SAATHI', '03/01/2018', NULL, 'Mr. Samir', NULL, 0, 'D&D', '2018-07-18 17:28:22', '2018-07-18 17:28:22'),
(3, 'PROJECT003', 'ACME-ESR', '05/01/2014', NULL, 'Mr. Veer Pratap', NULL, 0, 'Field force management', '2018-07-18 17:29:22', '2018-07-18 17:29:22'),
(4, 'PROJECT004', 'GPS Tracking Device', '07/01/2018', '07/31/2018', 'Logimetrix', NULL, 0, 'Product', '2018-07-18 17:43:31', '2018-07-18 17:43:31'),
(5, 'PROJECT005', 'SAG', '11/24/2016', NULL, 'NDDB', NULL, 0, 'NDDB', '2018-07-18 17:45:02', '2018-07-18 17:45:02'),
(6, 'PROJECT006', 'Infra app', '07/01/2018', '08/15/2018', 'Logimetrix Infra', NULL, 0, 'test', '2018-07-18 17:47:47', '2018-07-18 17:47:47'),
(7, 'PROJECT007', 'Digital Marketing', '07/15/2018', '05/31/2019', 'Logimetrix', NULL, 0, 'test', '2018-07-18 18:01:04', '2018-07-18 18:01:04'),
(8, 'PROJECT008', 'Data Mining', '07/15/2018', '08/22/2019', 'Logimetrix', NULL, 0, 'test', '2018-07-18 18:01:33', '2018-07-18 18:01:33'),
(9, 'PROJECT009', 'Sales Calling', '07/15/2018', '07/31/2019', 'Logimetrix', 'ajay@logimetrix.me', 1, 'test', '2018-07-18 18:02:16', '2019-02-15 14:17:40'),
(10, 'PROJECT0010', 'Documentation', '07/16/2018', '03/20/2019', 'Logimetrix', NULL, 0, 'test', '2018-07-18 18:02:48', '2018-07-18 18:02:48'),
(11, 'PROJECT0011', 'Acme- Drone (Android application)', '01/25/2019', NULL, 'Mr Veer', NULL, 0, 'Acme- Drone (Android application)', '2019-02-09 09:54:48', '2019-02-09 09:54:48'),
(12, 'PROJECT0012', 'Acme- Attendance', '01/05/2015', NULL, 'Mr Raaj Gopal', NULL, 0, 'Acme- Attendance', '2019-02-09 09:55:57', '2019-02-09 09:55:57'),
(13, 'PROJECT0013', 'Inventory management System', '02/01/2019', NULL, 'N/A', NULL, 0, 'Inventory management System', '2019-02-09 09:56:55', '2019-02-09 09:56:55'),
(14, 'PROJECT0014', 'Visitor Management System', '01/03/2017', NULL, 'Mr. Praveen Rai', NULL, 0, 'Visitor Management System', '2019-02-09 09:57:36', '2019-02-09 09:57:36'),
(15, 'PROJECT0015', 'SAAHAJ', '01/02/2017', NULL, 'MR. Surendra', NULL, 0, 'SAAHAJ', '2019-02-09 09:58:36', '2019-02-09 09:58:36'),
(16, 'PROJECT0016', 'The Dottedi', '03/08/2019', NULL, 'Naadiya Mirza', NULL, 0, 'The Dottedi (Magento)', '2019-02-09 09:59:40', '2019-02-09 09:59:40'),
(17, 'PROJECT0017', 'The weavenest', '02/01/2019', '08/16/2019', 'Mrs Richa Rai', NULL, 0, 'The weavenest', '2019-02-09 10:12:08', '2019-02-09 10:12:08'),
(18, 'PROJECT0018', 'Tirupati College ERP', '07/01/2018', '07/26/2019', 'Archit', NULL, 0, 'Tirupati College ERP', '2019-02-09 11:55:35', '2019-02-09 11:55:35'),
(19, 'PROJECT0019', 'Others', '02/01/2019', '07/27/2019', 'N/A', NULL, 0, NULL, '2019-02-15 18:33:49', '2019-02-15 18:33:49');

-- --------------------------------------------------------

--
-- Table structure for table `resignations`
--

CREATE TABLE `resignations` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `date_of_resign` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_working_day` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fnf_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_project_id` int(10) UNSIGNED DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_retracted` int(11) NOT NULL DEFAULT '0',
  `is_active` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Admin', NULL, NULL),
(2, 'HR Manager', NULL, NULL),
(4, 'Team Lead', NULL, NULL),
(5, 'IT Head', NULL, NULL),
(6, 'Web Developer', NULL, NULL),
(7, 'Android Developer', NULL, NULL),
(8, 'BDE', NULL, NULL),
(9, 'Sr. Web Developer', NULL, NULL),
(10, 'Sr. Android Developer', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `systems`
--

CREATE TABLE `systems` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_type_id` int(10) UNSIGNED NOT NULL,
  `master_system_id` int(11) NOT NULL,
  `system_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assign_to` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `systems`
--

INSERT INTO `systems` (`id`, `asset_type_id`, `master_system_id`, `system_id`, `name`, `assign_to`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'DT001', 'Desktop', NULL, '2018-12-14 10:52:18', '2018-12-14 10:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `system_assets`
--

CREATE TABLE `system_assets` (
  `id` int(10) UNSIGNED NOT NULL,
  `system_id` int(10) UNSIGNED NOT NULL,
  `asset_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `id` int(10) UNSIGNED NOT NULL,
  `team_leader_id` int(10) UNSIGNED NOT NULL,
  `team_member_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `team_leader_id`, `team_member_id`, `created_at`, `updated_at`) VALUES
(6, 69, 70, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(7, 69, 71, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(8, 69, 73, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(9, 69, 74, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(10, 69, 75, '2018-07-18 17:18:34', '2018-07-18 17:18:34'),
(11, 69, 76, '2018-07-18 17:18:46', '2018-07-18 17:18:46'),
(12, 69, 72, '2019-02-09 18:45:27', '2019-02-09 18:45:27'),
(13, 69, 79, '2019-02-09 18:45:27', '2019-02-09 18:45:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plain_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` int(11) NOT NULL,
  `department` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_json` text COLLATE utf8mb4_unicode_ci,
  `is_request_approved` int(11) NOT NULL DEFAULT '0',
  `is_active` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `plain_password`, `gender`, `role`, `department`, `remember_token`, `request_json`, `is_request_approved`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Super', 'Admin', 'shantanu@logimetrix.co.in', '$2y$10$zHqx6n40A.IDZJapG3clpODDJTHOGEnQv.6NgxNXEY2FVIpehNe.2', '123', NULL, 1, NULL, 'Y8rP1vqE46hThaMSu3hHxOKTyXlKyVU0IKVBslUAv830nPkQnbVIXSNzwGQO', NULL, 0, 1, '2017-12-26 12:55:26', '2018-06-27 10:06:56'),
(68, 'Abhishek Kumar', 'Mishra', 'abhishek@logimetrix.co.in', '$2y$10$eOwozHVc5SX2w3MRTOjvwe2/./YtswJZVAtswE7XLTXsuPx76BauS', '123456', 'male', 5, 'management', 'CaLJrvFPknjpHVgtPOJ5tTyLQYRvEPWGv6XIIFk1WRfNkiwMU58g6RNG9rYy', NULL, 0, 1, '2018-07-18 14:30:12', '2018-07-18 14:30:12'),
(69, 'Ajay', 'Kumar', 'ajay@logimetrix.me', '$2y$10$PMTcL9rZ/LHvkoKPgKiIpOExsbNcR3k2NHz8PF87wPaMWuQdpOnXG', '123456', 'male', 4, 'development', 'VMxE0NTtvtoo27E2MDd1YLMSPN7QcIH5SnmURrSa4DBY860VqsekVgqrZQML', NULL, 0, 1, '2018-07-18 14:40:56', '2018-07-18 14:40:56'),
(70, 'Puneet', 'Mishra', 'punnet@logimetrix.me', '$2y$10$3aV0xkIYtkhVZIgb8HQmS.Ll2O6..rCFAkfv9NdSLI26HFdiPL.06', '4545', 'male', 9, 'development', 'IQlH6dnjKW7p7N21ZT98quztZshIwDtVGCOZOIlbtaOdc6arbuLcwTh7z47Y', NULL, 0, 1, '2018-07-18 14:55:22', '2018-07-18 18:16:39'),
(71, 'Mohit', 'Kumar', 'mohit@logimetrix.co.in', '$2y$10$YgSS5HdIaqjTUJdByzz2n.YRdDv6j51CsS5Qnsd9GZG5VOlWQZJQW', '123456', 'male', 7, 'development', 'SLxOGGCrgln9r5scdTsCjHn6lW50CYiFkW1vUSEO63HnhURFRWt6l59kKrpn', NULL, 0, 1, '2018-07-18 15:04:52', '2019-02-09 11:08:28'),
(72, 'Pramod', 'Kumar Yadav', 'pramod@logimetrix.co.in', '$2y$10$5Xafg8rITUbwHF5DgDRiIuhUWeqwwyjnXb.NZxs26qTP8Y51Xa5X2', 'pramod@123', 'male', 7, 'development', 'DFvUXxCQjvnnJVVD2CJILHwK6JuGq0qimrbMbDb9JCkY2gOIXwNOgTleynuq', NULL, 1, 1, '2018-07-18 15:11:19', '2019-02-09 11:41:43'),
(73, 'Naveen', 'Sharma', 'naveen@logimetrix.co.in', '$2y$10$0YdVFhq3MLztNxGgvOJfe.00YsxJp390f6DC/AGw00QOiYlWEib/.', '123456', 'male', 7, 'development', 'xi0TNSXVJfRBEpdcMMb1dURNEYo738XpdyOQCRO6cRVI9mI3bp5gIRiipj81', NULL, 0, 1, '2018-07-18 15:17:36', '2018-07-18 15:17:36'),
(74, 'Amit', 'Chaurasiya', 'amit.chaurasiya@logimetrix.co.in', '$2y$10$1RgHXgoDmkfQpNEBtfIsFuG5U55H1M9/sdjkC2oKrRMZkK9.iZdzq', 'Amit1408@', 'male', 6, 'development', 'sY7IGloXK386cg8NSu8tDaNwYv25cEKuiwBHt5pc3vCuRuZltvgZumAJsQHC', NULL, 1, 1, '2018-07-18 15:25:20', '2019-03-04 10:01:05'),
(75, 'Saumya', 'Gupta', 'saumya@logimetrix.co.in', '$2y$10$FN8ZX7FtyghvjO4Vn38vge6aflsqShvn6.1EHFuYdMxA3yeY1u6.e', '123456', 'female', 6, 'development', 'DLTqWuV59IGP7sJdlSr29YFcYpFEo3gGgqOfXYG45r15rL4MfK9L7egTTN8A', NULL, 1, 1, '2018-07-18 15:31:46', '2019-02-09 11:44:28'),
(76, 'Arpita', 'upadhyay', 'arpita@logimetrix.co.in', '$2y$10$jDjuVzTJbsKNH5tJcE85ouGJFNvERq6EoB0L9vJk5WVVG6XwGOa8m', '123456', 'female', 8, 'sales', 'kKnjiCVztjYQpf6glecD7Eej9m9ZKhkdxOrk6CMZg4V4tR5tHiHOVljAWDss', NULL, 1, 1, '2018-07-18 15:35:36', '2019-03-04 10:00:55'),
(77, 'Raghvendra Pratap', 'Singh', 'raghvendra@logimetrix.co.in', '$2y$10$KcgwHm6lmkoDEBcmdxhOD.QMs44p.NZDRvzN912CSS0CBgdKD80Pa', 'raghu@123', 'male', 6, 'development', 'xoIz4Azr1rpfcdYYd4F5BOIHkbulBYmVNPRHtQW6eX4Hzh4pTVeZp7OoIHnd', NULL, 0, 1, '2018-07-18 15:42:50', '2018-07-18 15:42:50'),
(79, 'Ayush', 'Shukla', 'ayushshuklacs@gmail.com', '$2y$10$5dHQ4J.uFjJ8MH00NdJ8reJwS9BJmCScRyEj.Q1tPWx.CIraVP20i', '123456', 'male', 7, 'development', 'p5OaKeEuBlMaOkP9AwZ35m2vIOSOTdWqgpy73HJDH1zgUBj1lMgARlSnwq8S', NULL, 0, 1, '2019-02-09 10:30:52', '2019-02-09 10:30:52'),
(80, 'Anupam', 'Kumar', 'anupam@logimetrix.co.in', '$2y$10$sMRMUjIqg5XwGURoGDqdd.wHB1cc6V36KYsfsMrgnPyyj3WA/xBle', '123456', 'male', 8, 'sales', '2oQSHq2YSU0q6QP2FKJWk5KMSL8WJM4JAZVKaotyZt0ynRGWOR6nPILDquIk', NULL, 0, 1, '2019-02-28 13:15:49', '2019-02-28 13:15:49'),
(81, 'Shivani', 'Nigam', 'shivani@logimetrix.co.in', '$2y$10$DrPu9bf9XoVjLtLMbFkpuORAAurUi3WhRJNRDpYHN1fQq02MOEPLy', '123456', 'female', 8, 'management', 'pxfwBjFJIzX0PxaZmifD0EofesSII5hyjzQ5z5XdYV4SxJRtIat1hi5RPek9', NULL, 0, 1, '2019-03-15 17:57:26', '2019-03-15 17:57:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assets_asset_type_id_foreign` (`asset_type_id`),
  ADD KEY `assets_master_asset_id_foreign` (`master_asset_id`),
  ADD KEY `assets_asset_id_foreign` (`asset_id`);

--
-- Indexes for table `asset_assocs`
--
ALTER TABLE `asset_assocs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_assocs_asset_type_id_foreign` (`asset_type_id`),
  ADD KEY `asset_assocs_master_asset_id_foreign` (`master_asset_id`);

--
-- Indexes for table `asset_types`
--
ALTER TABLE `asset_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance_data`
--
ALTER TABLE `attendance_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance_filenames`
--
ALTER TABLE `attendance_filenames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance_managers`
--
ALTER TABLE `attendance_managers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attendance_managers_user_id_foreign` (`user_id`);

--
-- Indexes for table `dayType`
--
ALTER TABLE `dayType`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_cb_appraisal_details`
--
ALTER TABLE `employee_cb_appraisal_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_cb_appraisal_details_user_id_foreign` (`user_id`);

--
-- Indexes for table `employee_cb_profiles`
--
ALTER TABLE `employee_cb_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_cb_profiles_user_id_foreign` (`user_id`);

--
-- Indexes for table `employee_personal_details`
--
ALTER TABLE `employee_personal_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_personal_details_user_id_foreign` (`user_id`);

--
-- Indexes for table `employee_previous_employments`
--
ALTER TABLE `employee_previous_employments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_previous_employments_user_id_foreign` (`user_id`);

--
-- Indexes for table `employee_projects`
--
ALTER TABLE `employee_projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `eods`
--
ALTER TABLE `eods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `gps_data`
--
ALTER TABLE `gps_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leaves_user_id_foreign` (`user_id`),
  ADD KEY `leaves_leave_type_id_foreign` (`leave_type_id`);

--
-- Indexes for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_assets`
--
ALTER TABLE `master_assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `master_assets_asset_type_id_foreign` (`asset_type_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_sender_id_foreign` (`sender_id`),
  ADD KEY `notifications_receiver_id_foreign` (`receiver_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resignations`
--
ALTER TABLE `resignations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `resignations_user_id_foreign` (`user_id`),
  ADD KEY `current_project_id` (`current_project_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `systems`
--
ALTER TABLE `systems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `systems_asset_type_id_foreign` (`asset_type_id`);

--
-- Indexes for table `system_assets`
--
ALTER TABLE `system_assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_assets_system_id_foreign` (`system_id`),
  ADD KEY `system_assets_asset_id_foreign` (`asset_id`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_members_team_leader_id_foreign` (`team_leader_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `asset_assocs`
--
ALTER TABLE `asset_assocs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `asset_types`
--
ALTER TABLE `asset_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `attendance_data`
--
ALTER TABLE `attendance_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `attendance_filenames`
--
ALTER TABLE `attendance_filenames`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance_managers`
--
ALTER TABLE `attendance_managers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dayType`
--
ALTER TABLE `dayType`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employee_cb_appraisal_details`
--
ALTER TABLE `employee_cb_appraisal_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `employee_cb_profiles`
--
ALTER TABLE `employee_cb_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `employee_personal_details`
--
ALTER TABLE `employee_personal_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `employee_previous_employments`
--
ALTER TABLE `employee_previous_employments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `employee_projects`
--
ALTER TABLE `employee_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `eods`
--
ALTER TABLE `eods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=417;

--
-- AUTO_INCREMENT for table `gps_data`
--
ALTER TABLE `gps_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `leave_types`
--
ALTER TABLE `leave_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `master_assets`
--
ALTER TABLE `master_assets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `resignations`
--
ALTER TABLE `resignations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `systems`
--
ALTER TABLE `systems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `system_assets`
--
ALTER TABLE `system_assets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `asset_assocs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assets_asset_type_id_foreign` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assets_master_asset_id_foreign` FOREIGN KEY (`master_asset_id`) REFERENCES `master_assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `asset_assocs`
--
ALTER TABLE `asset_assocs`
  ADD CONSTRAINT `asset_assocs_asset_type_id_foreign` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_assocs_master_asset_id_foreign` FOREIGN KEY (`master_asset_id`) REFERENCES `master_assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `attendance_managers`
--
ALTER TABLE `attendance_managers`
  ADD CONSTRAINT `attendance_managers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `employee_cb_appraisal_details`
--
ALTER TABLE `employee_cb_appraisal_details`
  ADD CONSTRAINT `employee_cb_appraisal_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_cb_profiles`
--
ALTER TABLE `employee_cb_profiles`
  ADD CONSTRAINT `employee_cb_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_personal_details`
--
ALTER TABLE `employee_personal_details`
  ADD CONSTRAINT `employee_personal_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_previous_employments`
--
ALTER TABLE `employee_previous_employments`
  ADD CONSTRAINT `employee_previous_employments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_projects`
--
ALTER TABLE `employee_projects`
  ADD CONSTRAINT `employee_projects_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eods`
--
ALTER TABLE `eods`
  ADD CONSTRAINT `eods_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `leaves`
--
ALTER TABLE `leaves`
  ADD CONSTRAINT `leaves_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leaves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `master_assets`
--
ALTER TABLE `master_assets`
  ADD CONSTRAINT `master_assets_asset_type_id_foreign` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_receiver_id_foreign` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `resignations`
--
ALTER TABLE `resignations`
  ADD CONSTRAINT `resignations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `resignations_ibfk_2` FOREIGN KEY (`current_project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `systems`
--
ALTER TABLE `systems`
  ADD CONSTRAINT `systems_asset_type_id_foreign` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `team_members`
--
ALTER TABLE `team_members`
  ADD CONSTRAINT `team_members_team_leader_id_foreign` FOREIGN KEY (`team_leader_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
