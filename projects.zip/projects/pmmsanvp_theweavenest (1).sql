-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 30, 2019 at 12:04 PM
-- Server version: 5.6.41-84.1-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmmsanvp_theweavenest`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `user_name`, `password`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bagreview`
--

CREATE TABLE `tbl_bagreview` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `bag_name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_bagreview`
--

INSERT INTO `tbl_bagreview` (`id`, `name`, `email`, `message`, `bag_name`) VALUES
(1, 'Raghu', 'puneetm65@gmail.com', 'efdewfwqefewfc', ''),
(2, 'dewdew', 'puneetm65@gmail.com', 'frwefr4ewrf', 'ukjuyy'),
(3, 'saumya', 'saumya@logimetrix.co.in', 'kjhgfdewreytukjnbvfcgf', 'ukjuyy'),
(4, 'Anu', 'demo@gmail.com', 'dwmmmooo', 'new bag');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bags`
--

CREATE TABLE `tbl_bags` (
  `id` int(11) NOT NULL,
  `bag_name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `offerprice` varchar(255) NOT NULL,
  `bag_Discription` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_bags`
--

INSERT INTO `tbl_bags` (`id`, `bag_name`, `price`, `offerprice`, `bag_Discription`, `slug`, `product_image`) VALUES
(4, 'ukjuyy', '546', '243', 'rgthteyhfhbgrtr', 'ukjuyy', 'http://admin.theweavenest.com/uploads/product_image/1551964301.46519226_307983369809829_8774340528977215488_n.jpg'),
(5, 'new bag', '9000', '8000', 'hello', 'new-bag', 'http://admin.theweavenest.com/uploads/product_image/1551761885.s8.jpg'),
(6, 'fv', '5432', '2345', 'vcx', 'fv', 'http://admin.theweavenest.com/uploads/product_image/1551763244.41kkU2+62PL.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bag_images`
--

CREATE TABLE `tbl_bag_images` (
  `id` int(11) NOT NULL,
  `Bag_id` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_bag_images`
--

INSERT INTO `tbl_bag_images` (`id`, `Bag_id`, `product_image`) VALUES
(1, '1', 'http://admin.theweavenest.com/uploads/product_image/1551678805.s8.jpg'),
(2, '1', 'http://admin.theweavenest.com/uploads/product_image/1551678805.h3.jpg'),
(3, '1', 'http://admin.theweavenest.com/uploads/product_image/1551678805.b3.jpg'),
(4, '2', 'http://admin.theweavenest.com/uploads/product_image/1551678929.b3.jpg'),
(5, '2', 'http://admin.theweavenest.com/uploads/product_image/1551678929.logo.jpg'),
(6, '2', 'http://admin.theweavenest.com/uploads/product_image/1551678929.s8.jpg'),
(17, '3', 'http://admin.theweavenest.com/uploads/product_image/1551779253.90D460__675_Kanjivaram-A_grande.jpg'),
(31, '4', 'http://admin.theweavenest.com/uploads/product_image/1551964301.46519226_307983369809829_8774340528977215488_n.jpg'),
(9, '3', 'http://admin.theweavenest.com/uploads/product_image/1551680242.h3.jpg'),
(13, '5', 'http://admin.theweavenest.com/uploads/product_image/1551761885.s8.jpg'),
(14, '5', 'http://admin.theweavenest.com/uploads/product_image/1551761885.logo.jpg'),
(15, '5', 'http://admin.theweavenest.com/uploads/product_image/1551761885.2.jpg'),
(16, '6', 'http://admin.theweavenest.com/uploads/product_image/1551763244.41kkU2+62PL.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog`
--

CREATE TABLE `tbl_blog` (
  `id` int(11) NOT NULL,
  `blog_title` varchar(255) NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `detail_description` longtext NOT NULL,
  `date` varchar(255) NOT NULL,
  `blog_image` varchar(255) NOT NULL,
  `is_aproved` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_blog`
--

INSERT INTO `tbl_blog` (`id`, `blog_title`, `short_description`, `detail_description`, `date`, `blog_image`, `is_aproved`) VALUES
(16, 'Soul sprinkles', 'Welcome. Some tiny beads of inspiration and reflections about life', '<p>So, you want to be a marketing manager (or other marketing professional) - but perhaps you&rsquo;re not entirely sure what&rsquo;s expected of you?</p>\r\n\r\n<p>Well, firstly, congratulations on an excellent choice, both in terms of your career, and in your taste of articles, because here we&rsquo;re going to cover everything you need to know about marketing careers.</p>\r\n\r\n<p>Let&rsquo;s start with the basics, ok?</p>\r\n\r\n<h2>What Is A Marketing Manager And How Do I Become One?</h2>\r\n\r\n<p><img alt=\"\" src=\"https://ninjaoutreach.com/wp-content/uploads/2017/06/Great-marketing.png\" style=\"height:388px; width:662px\" /></p>\r\n\r\n<p>Marketing is a fairly nebulous term, which makes it difficult to sum up in a short marketing job description what exactly it means.</p>\r\n\r\n<p>Marketing at your company might mean something very different than marketing at another company depending on its size, its target market, its marketing philosophy, and its budget.</p>\r\n\r\n<p>Still, when it comes down to it, we can safely say that&nbsp;<strong>marketing is really just sales</strong>.</p>\r\n\r\n<p>Your job, as a marketer, is to present your company&rsquo;s product or service in a positive light to its&nbsp;<a href=\"https://ninjaoutreach.com/how-to-identify-target-audience/\">target audience</a>, in a way that creates buzz, attention, and for all intents and purposes drives more sales for the company.</p>\r\n\r\n<p>Now, specifically, a managerial role might be exactly what it sounds like&mdash;you may be managing other marketing specialists, setting the priorities, reviewing their work, and presenting to higher level executives on your team&rsquo;s progress.</p>\r\n\r\n<p>However, in the absence of a team, you might be executing the campaigns yourself (and still doing all of the above).</p>\r\n\r\n<h2>Interested in becoming a marketing manager?</h2>\r\n\r\n<p>Typical advice will point you to things like earning your bachelor&rsquo;s degree in marketing / business administration and joining a professional organization like the&nbsp;<a href=\"https://www.ama.org/\" target=\"_blank\">American Marketing Association&nbsp;</a>(AMA).</p>\r\n\r\n<p>Essentially, a litany of professional qualifications, some of which may no longer even be open to you!</p>\r\n\r\n<p>But, don&rsquo;t worry, I recommend the following, and you can get started on all of them today:</p>\r\n\r\n<p>First, get experience as a marketer! If no one will hire you, then start your own project, even if it&rsquo;s just something on the side.</p>\r\n\r\n<p>Meanwhile, educate yourself by reading about marketing online&mdash;there are a ton of resources.</p>\r\n\r\n<p>Frankly, you&rsquo;ll learn a lot more this way and it shows much more initiative when it comes time to talk about what you&rsquo;ve done during an interview.</p>\r\n\r\n<p>Next, develop your personal brand. Once you have experience, you have the right to exercise it, by speaking at events, or simply on marketing podcasts.</p>\r\n\r\n<p>Write a blog, and write&nbsp;<a href=\"https://ninjaoutreach.com/how-to-use-ninja-outreach-to-get-product-reviews-guest-posts-sponsored-posts-and-giveaways-2/\">guest posts</a>&nbsp;on other prominent blogs. Consult for companies. If no one will hire you, try working in exchange for a testimonial / reference to build up some contacts and more experience.</p>\r\n\r\n<p>Finally, now that you have experience and a personal brand, take that credibility and network, network, network!</p>\r\n\r\n<p>Doing this will turn the tables and people will be asking you to be their marketing manager instead of the other way around.</p>\r\n', '06-03-19', 'http://admin.theweavenest.com/uploads/blog_image/1551869148.12.jpg', ''),
(19, 'Manager, or Director?', 'More people are gravitating towards digital, which is why more marketers', '<p>Well, how long will it take you to do all of the above?</p>\r\n\r\n<p>There&rsquo;s no set time frame per sey, because, unlike becoming a doctor or a lawyer, there is no set path. It depends on how fast you can acquire experience, a network, etc.</p>\r\n\r\n<p>Generally speaking though, you&rsquo;re looking at a few years for each step, which is to say that you could probably become a marketing assistant without too much effort, and after a few years, a marketing manager, and finally after a few more years, a marketing director.</p>\r\n\r\n<h3>What Skills Are Needed To Be A Marketing Manager.......?</h3>\r\n\r\n<p>Marketers, by nature, tend to play in everyone&rsquo;s backyard. They may communicate with the design team, with the product team, with executives and assistants alike. As a result, it helps to have a diverse set of skills, such as:</p>\r\n\r\n<ul>\r\n	<li><strong>Being a persuasive communicator, especially possessing a good writing ability:</strong>&nbsp;You&rsquo;re going to be talking with a lot of different folks, and potentially leading a team. This requires you to have top notch interpersonal abilities, and perhaps above all the ability to sway people in the direction you want them to go, whether it&rsquo;s to supply you the budget to run a test or to try out&nbsp;<a href=\"https://ninjaoutreach.com/the-big-list-of-seo-tools-200/\">a new marketing tool</a>. Additionally, writing is still king when it comes to mass communication in the form of presentations, emails, briefs, and copywriting.</li>\r\n	<li><strong>Being a decisive leader:</strong>&nbsp;Did I mention you might be leading a team? If so, it will be your job to motivate and propel everyone forward. Perhaps the most difficult aspect, however, are the daily decisions you&rsquo;ll have to make in regards to the marketing campaigns you&rsquo;re running (which design should we go with? Should we stop the campaign, or wait for more results?).</li>\r\n	<li><strong>Possessing an analytical mind:</strong>&nbsp;Luckily, you won&rsquo;t be responsible for any NASA level math, however, it helps greatly to be familiar with the fundamental concepts of statistics, and being able to manipulate data (often in a spreadsheet like excel or google docs), to tease out the insights that are hidden there.</li>\r\n	<li><strong>Being creative:</strong>&nbsp;It&rsquo;s a noisy, noisy world out there, and chances are your product/service is not alone. If you want to get noticed, you&rsquo;ll have to come up with creative approaches that speak to your target market.</li>\r\n</ul>\r\n\r\n<h2>What Are A Marketing Manager&rsquo;s Jobs &amp; Responsibilities?</h2>\r\n\r\n<p>While every company operates differently, it wouldn&rsquo;t be uncommon for a marketing manager to have the following responsibilities.</p>\r\n\r\n<ul>\r\n	<li><strong>Setting the marketing calendar:</strong>&nbsp;People need to be told what to work on, and executives want a high level, transparent way to see what work is being done. A possible solution is to create some kind of marketing calendar or marketing board, which include what campaigns are active, who&rsquo;s working on them, when they&rsquo;re expected to be completed, and what other ideas are in the pipeline for later. Here&rsquo;s how ours looks:&nbsp;<img alt=\"\" src=\"https://ninjaoutreach.com/wp-content/uploads/2017/06/image1.jpg\" style=\"height:358px; width:750px\" /></li>\r\n	<li><strong>Leading a daily standup:</strong>&nbsp;You have to keep your team focused, and make sure they&rsquo;re working on the proper priorities and hitting deadlines. While you&rsquo;ll probably communicate with each person individually in person or using a chat app like Slack, a daily standup is an effective way to bring everyone together to discuss objectives, progress, and to make adjustments with everyone&rsquo;s input.</li>\r\n	<li><strong>Reviewing progress / results:</strong>&nbsp;As your marketing assistants will be responsible for executing the campaigns for you, you&rsquo;ll be needed to advise on the results and set the clear next steps. For example, you may have to review the results of a recent A/B test that was run to determine if the control should remain or be replaced.</li>\r\n	<li><strong>Reporting to executives:</strong>&nbsp;A manager is a mid level position that typically is the bridge between executives and assistants, which means you&rsquo;ll constantly be taking the results from your assistants and summarizing them for the executives, while simultaneously taking the business objectives from the executives and using them to set priorities for your assistants.</li>\r\n	<li><strong>Making budget recommendations:</strong>&nbsp;Depending on the size and level of involvement of your finance department, you will probably be responsible for some degree of budgeting, which is to say that you will have to make recommendations on which tools should be bought, which campaigns deserve more or less money based on their results, etc.</li>\r\n</ul>\r\n\r\n<h2>What&rsquo;s It Like Being A Marketing Manager?</h2>\r\n\r\n<p>Your company&rsquo;s culture is probably going to have the largest effect on your day to day. Some companies have very strict deadlines, operate under a tight budget, demand a high level of results, whereas others tend to operate a lot more loosely, have more cash to burn, and are comfortable with more qualitative insights.</p>\r\n\r\n<p>In short, being a marketing manager can be stressful, just like all types of managerial jobs, but it can also be very rewarding as you traditionally have a lot of control and influence in the company&rsquo;s branding and the way it &lsquo;speaks&rsquo; to customers, which, aside from being a very powerful position, allows for a large degree of creativity.</p>\r\n\r\n<h2>Should I Learn Digital Or Traditional Marketing?</h2>\r\n\r\n<p>Digital marketing is essentially marketing applied through&nbsp;<a href=\"https://ninjaoutreach.com/my-secret-traffic-generation-strategy-for-2015/\">digital channels</a>.</p>\r\n\r\n<p>Now, marketing has always been about getting in front of your target audience. However, your audience has likely changed in the last decade or so.</p>\r\n\r\n<p>More people are gravitating towards digital, which is why more marketers are developing an expertise in this area.</p>\r\n\r\n<p>Consider where you typically get your information from. If you&rsquo;re like most people, chances are it&rsquo;s things like:</p>\r\n\r\n<ul>\r\n	<li>Your email</li>\r\n	<li>Your phone</li>\r\n	<li>Websites you visit</li>\r\n</ul>\r\n\r\n<p>As opposed to more traditional media such as:</p>\r\n\r\n<ul>\r\n	<li>Magazines</li>\r\n	<li>Billboards</li>\r\n	<li>Radio</li>\r\n</ul>\r\n\r\n<p>Of course, that&rsquo;s not to say that traditional media outlets are obsolete&mdash;far from it, BUT certainly the trend is digital.</p>\r\n\r\n<p>Overall, your company will dictate its&nbsp;<a href=\"https://ninjaoutreach.com/coca-cola-marketing-plan/\">marketing strategy</a>, still, keep an eye out for opportunities in the digital space.</p>\r\n\r\n<h2>What Do Marketers Make For A Salary?</h2>\r\n\r\n<p>The answer to this question is going to vary significantly based on factors such as:</p>\r\n\r\n<ol>\r\n	<li>Which country do you live in?</li>\r\n	<li>Do you live in a major metropolitan area?</li>\r\n	<li>Is the company you work for, for profit?</li>\r\n	<li>How many years of experience do you have?</li>\r\n</ol>\r\n\r\n<p>In short, we can supply some statistics from the US Bureau of Labor to give a general idea of salaries for a few marketing roles - but at best this is a guideline. If you have a specific company you&rsquo;re targeting, see if they&rsquo;re on&nbsp;<a href=\"https://glassdoor.com/\" target=\"_blank\">GlassDoor&nbsp;</a>to get a glimpse of the salaries and culture.</p>\r\n\r\n<p>All in all, Perhaps the most useful thing one can say is that being a marketer, specifically<strong>&nbsp;a marketing manager or higher, is an above average salary just about wherever you are.</strong></p>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<th>MARKETING CAREER</th>\r\n			<th>MEDIAN ANNUAL SALARY*</th>\r\n		</tr>\r\n		<tr>\r\n			<td>Marketing Specialist</td>\r\n			<td>$61,290</td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href=\"https://ninjaoutreach.com/6-easy-steps-to-research-your-market-like-an-expert/\">Market Research</a>&nbsp;Analyst</td>\r\n			<td>$61,290</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Advertising Manager</td>\r\n			<td>$123,450</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Public Relations Manager</td>\r\n			<td>$101,510</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Marketing Manager</td>\r\n			<td>$123,450</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>Sources:</strong>&nbsp;U.S. Bureau of Labor Statistics Occupational Outlook Handbook, 2016-17 Edition</p>\r\n\r\n<p>And perhaps most importantly, is that marketing is a career that, while always evolving, is very unlikely to ever become obsolete (people will always have things to sell), and in most places<a href=\"https://www.bls.gov/emp/ep_table_104.htm\" target=\"_blank\">&nbsp;is growing faster than other careers</a>.</p>\r\n\r\n<p>For example, LinkedIn shows over 16k job openings for the role &ldquo;Marketing Manager&rdquo;.</p>\r\n\r\n<p><img alt=\"\" src=\"https://ninjaoutreach.com/wp-content/uploads/2017/06/Marketing-manager-jobs-opennings-on-LinkedIn.png\" style=\"height:233px; width:750px\" /></p>\r\n\r\n<h2>What Tools Do Marketers Use?</h2>\r\n\r\n<p>It&rsquo;s not uncommon for a marketer to be versed in dozens of different tools, and while there is much more to marketing than the tools you know, it&rsquo;s definitely important to be well versed in a variety of tools for things like acquisition, analytics, customer management, content creation, and a whole host of other marketing activities.</p>\r\n\r\n<p>We&rsquo;ve recommended the tools that&nbsp;<a href=\"https://ninjaoutreach.com/tools/\">we personally use at NinjaOutreach here</a>&nbsp;and I encourage you to look through them, not only to see if there are any ones you&rsquo;re not familiar with, but also to understand the different topics and purposes for which tools exist.</p>\r\n\r\n<h2>What Marketing Terms Should You Know?</h2>\r\n\r\n<p>New marketing terms surface every year, and the easiest way to stay abreast of what&rsquo;s trending is to always be learning i.e reading blog posts, listening to podcasts, and attending conferences.</p>\r\n\r\n<p>However, some terms seem to never die. I won&rsquo;t reinvent the wheel by defining what&rsquo;s already been defined, but instead will list the&nbsp;<a href=\"https://blog.hubspot.com/marketing/inbound-marketing-glossary-list\" target=\"_blank\">99 Top Marketing Terms identified by Hubspot</a>, to which you can reference the ones that seem unfamiliar to you.</p>\r\n\r\n<ol>\r\n	<li>&nbsp;</li>\r\n</ol>\r\n\r\n<p><img alt=\"\" src=\"https://ninjaoutreach.com/wp-content/uploads/2017/06/When-to-start.png\" style=\"height:593px; width:599px\" /></p>\r\n\r\n<p>Well, there you have it&mdash;you&rsquo;ve been properly debriefed on what you&#39;re in for if you decide to pursue a career in marketing!</p>\r\n\r\n<p>Personally, as a marketer myself, I find it&rsquo;s been a rewarding career that keeps me challenged and curious just about daily, and for that reason, recommend it for someone who is genuinely interested in this exciting field.</p>\r\n', '06-03-19', 'http://admin.theweavenest.com/uploads/blog_image/1551869298.14.jpg', ''),
(21, 'the Kanchipuram', 'The Kanchipuram Silk Sarees are made of pure silk,', '<p>Ask any South Indian woman what the Kanjeevaram saree means to her, she will inevitably state an expected fact &ndash; it is a rich-looking smooth ocean of silk that is meant for display at exclusive occasions and a possession to be prized for life. The South Indian answer to the famed Banarasi Silks of Northern India, Kanjeevarams or Kanchipuram silks are definitely the pride of the wearer and the envy of onlookers.</p>\r\n\r\n<p><strong>What is special about the Kanchipuram Silk Saree?</strong></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.unnatisilks.com/blog/wp-content/uploads/2016/01/SR5067-b_original-200x300.jpg\" style=\"height:300px; width:200px\" />The&nbsp;<a href=\"http://www.unnatisilks.com/sarees-online/by-popular-variety-name-sarees/kanchipuram-silk.html\" target=\"_blank\">Kanchipuram Silk Sarees</a>&nbsp;are made of pure silk, with motifs having zari of silk threads dipped in liquid gold and silver. For it to be classified as a Kanjeevaram Sari, Geographical Indication (GI) stricture stipulates that the decorative zari must have at least 57% silver and 0.6% gold in it.</p>\r\n\r\n<p>The special appeal of this seemingly royal venture are the very intricate designs that are woven into the body in gold threads of human and animal figures of geometric designs with temple towers along the border. The borders have wide contrast. Temple borders, checks, stripes and floral (buttas) are traditional designs found on a Kanchipuram sarees. The base material, silk, is also known for its quality and craftsmanship. Good fine count weaves with suitable enhancement, suitable linings and smooth texture, with the special shimmer quality have kept its reputation as a valuable product to be carefully stored and displayed on those special occasions like weddings, grand parties, big festivals, social functions. No wonder its market value has not diminished over time. &nbsp;If the Kanchipuram sarees vary widely in cost it is only depending upon the intricacy of work, colors, pattern, material used like&nbsp;zari&nbsp;(gold thread) etc. Priced from a modest Rs. 2000/-, the Kanchipuram Silk Saree could be upto a lakh and above, based on the design, motif and materials used.</p>\r\n\r\n<p>In order to get the protection and continued sustenance for a valuable product that is the outcome of devotion and dedication, the Kanchipuram Saree has acquired the Geographical Indication label in 2005 for its origin.</p>\r\n\r\n<p>For all varieties mentioned above, and under a single roof,&nbsp;<strong><a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/unnatisilks.com\">Unnati</a>&nbsp;</strong>with an association of three decades with master weavers and their art has it all and much more.</p>\r\n\r\n<p>&ndash;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; A social cause of promoting traditional excellence through encouragement of quality handloom sarees in fine silk, cotton and other fabric materials, &ndash;</p>\r\n\r\n<p>&ndash;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Providing opportunities for weavers to excel in their craft through brilliant fusion of traditional and trendy,</p>\r\n\r\n<p>&ndash;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Creating awareness of India&rsquo;s rich heritage in handloom fabrics through novel, innovative and inspiring creations from all corners of India at attractive prices wholesale and detail,</p>\r\n\r\n<p>the Unnati zeal and passion for traditional handlooms has not dimmed but increased manifold in its progress forward.</p>\r\n\r\n<p><strong><em>Weddings are a necessary part of life, celebrated with pomp and splendour in all parts of the world. But Indian weddings are celebrated with gusto and gaiety for the Indian society at large to come out in numbers and spend their time in revelry. The silk saris of grandeur that find their place of pride in the Indian wedding and as exclusive as the occasion, make it special for the Indian woman who attend, who utilize this heaven sent opportunity to&nbsp; flaunt their silky treasures, arouse envy and exchange notes for future purchases. &nbsp; &nbsp;</em></strong></p>\r\n\r\n<p>There are very many traditional silk handlooms in the south like&nbsp;<strong><a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/mysore-silk-sarees-online.html\">Mysore</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/kanchipuram-silk.html\">Kanjeevaram</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/dharmavaram-pattu-silk-sarees.html\">Dharmavaram</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/arani-silk-pattu-saris.html\">Arani</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/rasipuram-silk-sarees-online.html\">Rasipuram</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/venkatagiri-sarees.html\">Venkatagiri</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/coimbatore-kovai-sarees-online.html\">Coimbatore</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/pochampally-silk-sarees.html\">Pochampally</a>,&nbsp;</strong>Narayanpet<strong>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/bangalore-silk-sarees.html\">Bangalore</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/uppada-silk-sarees.html\">Uppada</a>,&nbsp;<a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/gadwal-silk-sarees.html\">Gadwal</a>,</strong>&nbsp;<strong><a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/mangalagiri-sarees.html\">Mangalagiri Silks</a>.&nbsp;&nbsp;</strong>&nbsp;&nbsp;Bangalore and Mysore in Karnataka, India, are famous for their individual brands of silk, especially the Mysore variety, which has since long been cherished for its unique qualities.</p>\r\n\r\n<p>Kanchipuram or Kanjeevaram Sarees also have a special place in the fabric world. Like the Mysore Silks, the Kanchipuram Silks are made of pure silk, with motifs having zari of silk threads dipped in liquid gold and silver. The appeal of the Kanjeevaram Silks lies in the elegant broad borders with colours and designs different from that of the body. Typical motifs are sun, moon, peacock, swan, lion and mango. Themes like jasmine flowers scattered between boundaries, parallel lines running across or temple structures are quite popular.</p>\r\n\r\n<p><img alt=\"red-banarasi-saris\" src=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/red-banarasi-saris-300x225.jpg\" style=\"height:225px; width:300px\" />The Northern India of course has the century old &nbsp;<strong><a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/banarasi-silk-sarees.html\">Banarasi</a>&nbsp;</strong>Saree with its traditional decorative finery and extremely rich zari work in pure gold that is a necessary part of the wedding, the sangeet ceremony, the mehandi rasm, the reception and other grand occasions like parties, festivals like Deepawali, Dushhera, Holi etc.</p>\r\n\r\n<p><strong><a href=\"https://www.unnatisilks.com/blog/wp-content/uploads/2014/12/chanderi-silk-saris.html\">Chanderi Silks</a></strong>&nbsp;of Madhya Pradesh (MP), are known for their sheer quality, fine texture and marvellous work in art and design. Chanderi Silks have zari brocades with embroidery of different patterns as Zari, Zardosi, Ari, Gota, Chikan, to name a few. Tussar Silk, also known as &lsquo;Kosa&rsquo; Silk is &lsquo;wild silk&rsquo;, of a deep golden colour and good texture,&nbsp;and is from the forests of Jharkhand, Chattisgarh. This fine silk yarn also known as Vanya silk is what is available for the tribals to show their artistry and craftsmanship in hand painted thematic art in eco-friendly colours and exotic batik, sharp and detailed miniature depictions on well-woven Tussar Silk fabrics, known for their zari borders, motifs and the hand crafted designs that enrich them.....</p>\r\n', '07-03-19', 'http://admin.theweavenest.com/uploads/blog_image/1551957214.banner.jpg', ''),
(20, 'Scott Stratten', 'â€œToo often, feeling intimidated becomes our excuse not to be awesome.', '<h2>&ldquo;Opportunities don&rsquo;t happen, you create them.&rdquo;<a href=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Chris-Grosser.png\"><img alt=\"Quote Chris Grosser\" src=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Chris-Grosser.png\" style=\"height:375px; width:250px\" /></a></h2>\r\n\r\n<p><strong>Chris Grosser</strong></p>\r\n\r\n<p>I have heard people complain that they did not get this or that opportunity or that someone else was just lucky. Well, the truth is that luck is only a small part of it. Because some people go through their life and create opportunities one of which is maybe going to be their key to success. Other people just sit on their sofa complaining that they never got a chance.</p>\r\n\r\n<p>Go out there. Create opportunities. Start doing, today!</p>\r\n\r\n<h2><a href=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Scott-Stratten.png\"><img alt=\"\" src=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Scott-Stratten.png\" style=\"height:375px; width:250px\" /></a>&ldquo;Too often, feeling intimidated becomes our excuse not to be awesome.&rdquo;</h2>\r\n\r\n<p><strong>Scott Stratten/......</strong></p>\r\n\r\n<p>Are you still dreaming of starting a &nbsp;blog or a business? Do you want to change your life? Are you too afraid and intimidated to actually do it?</p>\r\n\r\n<p>What is the worst that can happen? You won&rsquo;t get what you wanted. What is the best that can happen? It can be awesome. Dare to be awesome!</p>\r\n\r\n<h2>&ldquo;Don&rsquo;t&nbsp;Settle: Don&rsquo;t finish crappy books. If you don&rsquo;t like the menu, leave the restaurant. If&nbsp;you&rsquo;re&nbsp;not on the right path get off it.&rdquo;<a href=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Chris-Brogan.png\"><img alt=\"\" src=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Chris-Brogan.png\" style=\"height:375px; width:250px\" /></a></h2>\r\n\r\n<p><strong>Chris Brogan</strong></p>\r\n\r\n<p>Life is far too short to settle for things you do not want. Whether it be books, food, a bad relationship, or the wrong life:</p>\r\n\r\n<p>Don&rsquo;t settle for something you do not enjoy, it is up to you to do better and create the life you want to live!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2>&ldquo;Don&rsquo;t&nbsp;raise&nbsp;your voice, improve your argument.&rdquo;</h2>\r\n\r\n<p><strong><a href=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Desmond-Tutu.png\"><img alt=\"\" src=\"https://blog.thesocialms.com/wp-content/uploads/2018/06/Quote-Desmond-Tutu.png\" style=\"height:375px; width:250px\" /></a>Desmond Tutu</strong></p>\r\n\r\n<p>If it does not work, no amount of shouting will solve it! If one tweet does not work, 10 tweets of the same won&rsquo;t make it better. Raising the level of annoying shouting will not improve your results. Instead, learn and change your argument.</p>\r\n\r\n<p>If your arguments are wrong, no number of repeating them or raising your voice will give you the success you are looking for.</p>\r\n\r\n<h2>&ldquo;Success is normally found in pile of mistakes&rdquo;</h2>\r\n', '06-03-19', 'http://admin.theweavenest.com/uploads/blog_image/1551873789.10.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `Discription` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `category`, `Discription`) VALUES
(16, 'Silk', 'Silk is a natural protein fiber, some forms of which can be woven into textiles. The protein fiber of silk is composed mainly of fibroin and is produced by certain insect larvae to form cocoons.[1] The best-known silk is obtained from the cocoons of the l'),
(17, 'Cotton', 'Cotton is a soft, fluffy staple fiber that grows in a boll, or protective case, around the seeds of the cotton plants of the genus Gossypium in the mallow family Malvaceae. The fiber is almost pure cellulose. Under natural conditions, the cotton bolls wil'),
(18, 'Linen', 'Linen /ËˆlÉªnÉªn/ is a textile made from the fibers of the flax plant. Linen is laborious to manufacture, but the fiber is very strong, absorbent and dries faster than cotton. Garments made of linen are valued for their exceptional coolness and freshness ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contactus`
--

CREATE TABLE `tbl_contactus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contactus`
--

INSERT INTO `tbl_contactus` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'demo', 'demo@gmail.com', 'regarding saree purchase', 'dswcdfvgnhc vs\\cdgfthut'),
(2, 'Raghu', 'puneetm65@gmail.com', 'dxasx', 'dewdewf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_image`
--

CREATE TABLE `tbl_image` (
  `id` int(11) NOT NULL,
  `Product_id` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_image`
--

INSERT INTO `tbl_image` (`id`, `Product_id`, `product_image`) VALUES
(1, '44', 'http://admin.theweavenest.com/uploads/product_image/1551182107.9.jpg'),
(80, '64', 'http://admin.theweavenest.com/uploads/product_image/1551936611.90D460__675_Kanjivaram-A_grande.jpg'),
(3, '44', 'http://admin.theweavenest.com/uploads/product_image/1551182107.2.jpg'),
(73, '45', 'http://admin.theweavenest.com/uploads/product_image/1551875585.8.jpg'),
(5, '45', 'http://admin.theweavenest.com/uploads/product_image/1551184308.90D460__675_Kanjivaram-A_grande.jpg'),
(6, '46', 'http://admin.theweavenest.com/uploads/product_image/1551329457.5.jpg'),
(7, '46', 'http://admin.theweavenest.com/uploads/product_image/1551329457.4.jpg'),
(8, '46', 'http://admin.theweavenest.com/uploads/product_image/1551329457.3.jpeg'),
(9, '47', 'http://admin.theweavenest.com/uploads/product_image/1551332379.b4.jpg'),
(10, '47', 'http://admin.theweavenest.com/uploads/product_image/1551332379.b5.jpg'),
(11, '48', 'http://admin.theweavenest.com/uploads/product_image/1551334459.h3.jpg'),
(72, '45', 'http://admin.theweavenest.com/uploads/product_image/1551875543.'),
(71, '61', 'http://admin.theweavenest.com/uploads/product_image/1551875540.7.jpg'),
(13, '48', 'http://admin.theweavenest.com/uploads/product_image/1551334459.s8.jpg'),
(14, '49', 'http://admin.theweavenest.com/uploads/product_image/1551334640.h3.jpg'),
(15, '49', 'http://admin.theweavenest.com/uploads/product_image/1551334640.h2.jpg'),
(16, '49', 'http://admin.theweavenest.com/uploads/product_image/1551334640.l8.jpg'),
(17, '50', 'http://admin.theweavenest.com/uploads/product_image/1551335324.b3.jpg'),
(18, '50', 'http://admin.theweavenest.com/uploads/product_image/1551335324.h3.jpg'),
(19, '50', 'http://admin.theweavenest.com/uploads/product_image/1551335324.s8.jpg'),
(20, '51', 'http://admin.theweavenest.com/uploads/product_image/1551335918.b3.jpg'),
(21, '51', 'http://admin.theweavenest.com/uploads/product_image/1551335918.b4.jpg'),
(22, '51', 'http://admin.theweavenest.com/uploads/product_image/1551335918.l8.jpg'),
(23, '52', 'http://admin.theweavenest.com/uploads/product_image/1551335998.b3.jpg'),
(24, '52', 'http://admin.theweavenest.com/uploads/product_image/1551335998.h3.jpg'),
(25, '53', 'http://admin.theweavenest.com/uploads/product_image/1551336257.h3.jpg'),
(26, '53', 'http://admin.theweavenest.com/uploads/product_image/1551336257.b3.jpg'),
(27, '53', 'http://admin.theweavenest.com/uploads/product_image/1551336257.h3.jpg'),
(28, '54', 'http://admin.theweavenest.com/uploads/product_image/1551336289.h2.jpg'),
(29, '54', 'http://admin.theweavenest.com/uploads/product_image/1551336289.h3.jpg'),
(30, '0', 'http://admin.theweavenest.com/uploads/product_image/1551523831.41kkU2+62PL.jpg'),
(31, '56', 'http://admin.theweavenest.com/uploads/product_image/1551351466.l1.jpg'),
(32, '56', 'http://admin.theweavenest.com/uploads/product_image/1551351466.l9.jpg'),
(33, '56', 'http://admin.theweavenest.com/uploads/product_image/1551351466.l4.jpg'),
(35, '57', 'http://admin.theweavenest.com/uploads/product_image/1551419677.b4.jpg'),
(76, '60', 'http://admin.theweavenest.com/uploads/product_image/1551875808.7.jpg'),
(37, '58', 'http://admin.theweavenest.com/uploads/product_image/1551419844.h2.jpg'),
(38, '58', 'http://admin.theweavenest.com/uploads/product_image/1551419844.h3.jpg'),
(39, '58', 'http://admin.theweavenest.com/uploads/product_image/1551419844.'),
(40, '59', 'http://admin.theweavenest.com/uploads/product_image/1551421208.h2.jpg'),
(41, '59', 'http://admin.theweavenest.com/uploads/product_image/1551421208.s8.jpg'),
(42, '57', 'http://admin.theweavenest.com/uploads/product_image/1551527917.90D460__675_Kanjivaram-A_grande.jpg'),
(45, '57', 'http://admin.theweavenest.com/uploads/product_image/1551529356.'),
(77, '63', 'http://admin.theweavenest.com/uploads/product_image/1551875919.7.jpg'),
(75, '61', 'http://admin.theweavenest.com/uploads/product_image/1551875762.7.jpg'),
(81, '64', 'http://admin.theweavenest.com/uploads/product_image/1551936641.'),
(78, '63', 'http://admin.theweavenest.com/uploads/product_image/1551875919.4.jpg'),
(52, '62', 'http://admin.theweavenest.com/uploads/product_image/1551873237.9.jpg'),
(65, '62', 'http://admin.theweavenest.com/uploads/product_image/1551874854.'),
(115, '24', 'http://admin.theweavenest.com/uploads/product_image/1551951513.90D460__675_Kanjivaram-A_grande.jpg'),
(69, '48', 'http://admin.theweavenest.com/uploads/product_image/1551874950.'),
(56, '59', 'http://admin.theweavenest.com/uploads/product_image/1551873484.8.jpg'),
(57, '59', 'http://admin.theweavenest.com/uploads/product_image/1551873517.6.jpg'),
(96, '60', 'http://admin.theweavenest.com/uploads/product_image/1551940771.41kkU2+62PL.jpg'),
(105, '24', 'http://admin.theweavenest.com/uploads/product_image/1551949627.0002445_traditional-soft-silk-saree.jpeg'),
(74, '41', 'http://admin.theweavenest.com/uploads/product_image/1551875698.8.jpg'),
(97, '60', 'http://admin.theweavenest.com/uploads/product_image/1551940771.0002445_traditional-soft-silk-saree.jpeg'),
(103, '41', 'http://admin.theweavenest.com/uploads/product_image/1551943898.'),
(113, '24', 'http://admin.theweavenest.com/uploads/product_image/1551951142.2086069.jpg'),
(128, '66', 'http://admin.theweavenest.com/uploads/product_image/1552288293.0002445_traditional-soft-silk-saree.jpeg'),
(116, '65', 'http://admin.theweavenest.com/uploads/product_image/1552037581.5.jpg'),
(117, '65', 'http://admin.theweavenest.com/uploads/product_image/1552037581.7.jpg'),
(118, '65', 'http://admin.theweavenest.com/uploads/product_image/1552037581.23.jpg'),
(119, '64', 'http://admin.theweavenest.com/uploads/product_image/1552038264.90D460__675_Kanjivaram-A_grande.jpg'),
(120, '25', 'http://admin.theweavenest.com/uploads/product_image/1552038329.41kkU2+62PL.jpg'),
(121, '25', 'http://admin.theweavenest.com/uploads/product_image/1552038354.download.jpg'),
(122, '31', 'http://admin.theweavenest.com/uploads/product_image/1552038418.designer-linen-saree-500x500.jpg'),
(123, '31', 'http://admin.theweavenest.com/uploads/product_image/1552038437.48368087_317411718866994_5968841369806962688_n.jpg'),
(124, '31', 'http://admin.theweavenest.com/uploads/product_image/1552038459.0002445_traditional-soft-silk-saree.jpeg'),
(125, '32', 'http://admin.theweavenest.com/uploads/product_image/1552038516.90D460__675_Kanjivaram-A_grande.jpg'),
(126, '34', 'http://admin.theweavenest.com/uploads/product_image/1552038535.0002445_traditional-soft-silk-saree.jpeg'),
(127, '37', 'http://admin.theweavenest.com/uploads/product_image/1552038624.90D460__675_Kanjivaram-A_grande.jpg'),
(129, '70', 'http://admin.theweavenest.com/uploads/product_image/1552304110.41kkU2+62PL.jpg'),
(130, '71', 'http://admin.theweavenest.com/uploads/product_image/1552373710.46525729_307983896476443_6681608192058720256_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `subcategory` varchar(255) NOT NULL,
  `Product` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `offerprice` int(255) NOT NULL,
  `Discription` varchar(255) NOT NULL,
  `is_new_arrival` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `category`, `subcategory`, `Product`, `price`, `offerprice`, `Discription`, `is_new_arrival`, `product_image`, `slug`) VALUES
(24, '16', '14', 'sdhju', 685, 0, 'nhfrhrhbgr', 'on', 'http://admin.theweavenest.com/uploads/product_image/1551951513.90D460__675_Kanjivaram-A_grande.jpg', 'sdhju'),
(25, '16', '14', 'asddsw', 546, 0, 'bhyrhbgthyrh', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552038354.download.jpg', 'asddsw'),
(26, '17', 'cottonnew', 'sdcq', 766, 0, 'bgfnbbsvgr', '', 'http://admin.theweavenest.com/uploads/product_image/1551163724.5.jpg', 'sdcq'),
(27, '18', 'linencotton', 'znhn', 978, 0, 'gbgvvfrs', '', 'http://admin.theweavenest.com/uploads/product_image/1551163743.22.jpg', 'znhn'),
(28, '18', 'linencotton', 'luoluihy', 987, 0, 'vfvgrrefW', '', 'http://admin.theweavenest.com/uploads/product_image/1551163767.16.jpg', 'luoluihy'),
(29, '17', 'cottonnew', 'jjoihhuggvjhvuhv', 8657647, 0, 'cnsiufhnufhreiugfhregur', '', 'http://admin.theweavenest.com/uploads/product_image/1551163811.4.jpg', 'jjoihhuggvjhvuhv'),
(31, '16', '14', 'asds', 122, 0, 'wwefcewc', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552038459.0002445_traditional-soft-silk-saree.jpeg', 'asds'),
(32, '16', '14', 'mjkijyug', 9887, 0, 'vgrgtvesftrv', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552038516.90D460__675_Kanjivaram-A_grande.jpg', 'mjkijyug'),
(33, '17', 'cottonnew', 'gbftr', 45645, 0, 'gfregfregfv', '', 'http://admin.theweavenest.com/uploads/product_image/1551178670.9.jpg', 'gbftr'),
(34, '16', '14', '987y6', 988787, 0, 'guhygyuygfuygyugiy', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552038535.0002445_traditional-soft-silk-saree.jpeg', '987y6'),
(35, '16', '14', 'swsq', 43, 0, 'grtgvrfd', 'on', 'http://admin.theweavenest.com/uploads/product_image/1551179579.2.jpg', 'swsq'),
(36, '17', 'cottonnew', 'gtrgtrg', 667, 0, 'hgfthrfths', '', 'http://admin.theweavenest.com/uploads/product_image/1551179667.15.jpg', 'gtrgtrg'),
(37, '16', '14', 'ferf', 45645, 0, 'vfevfdsge', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552038624.90D460__675_Kanjivaram-A_grande.jpg', 'ferf'),
(38, '16', '14', 'sws', 22, 0, 'wex', 'on', 'http://admin.theweavenest.com/uploads/product_image/1551180442.3.jpeg', 'sws'),
(40, '16', '14', 'proper', 1, 0, 'demo', 'on', 'http://admin.theweavenest.com/uploads/product_image/1551181407.2.jpg', 'proper'),
(41, '18', '14', 'ghjgj', 425, 98, 'vhjb', 'on', 'http://admin.theweavenest.com/uploads/product_image/1551181531.8.jpg', 'ghjgj'),
(42, '16', '14', 'bf', 12, 0, 'bsg', 'on', 'http://admin.theweavenest.com/uploads/product_image/1551181830.1.jpg', 'bf'),
(43, '16', 'banarasisilk', 'bf', 12, 0, 'bsg', '', 'http://admin.theweavenest.com/uploads/product_image/1551181984.1.jpg', 'bf'),
(44, '16', 'banarasisilk', 'test', 2, 0, 'test2', '', 'http://admin.theweavenest.com/uploads/product_image/1551182107.9.jpg', 'test'),
(46, '17', 'cottonnew', 'demoooo', 123, 0, 'asdfghjkl', '', 'http://admin.theweavenest.com/uploads/product_image/1551329457.5.jpg', 'demoooo'),
(47, '18', '14', 'asd', 123, 0, 'ddfrggfr', '', 'http://admin.theweavenest.com/uploads/product_image/1551332379.b4.jpg', 'asd'),
(49, '16', 'banarasisilk', 'jhj', 40, 0, 'dfcergfre', '', 'http://admin.theweavenest.com/uploads/product_image/1551334640.h3.jpg', 'jhj'),
(50, '18', 'linencotton', 'assdfd', 334, 0, 'dswefwe', '', 'http://admin.theweavenest.com/uploads/product_image/1551335324.b3.jpg', 'assdfd'),
(51, '18', 'linencotton', 'dddd', 500, 400, 'njjckcfkjfnueucufrgfhbdjcbkj  hhhy42fdr3fd3fr3fr3rf3frr8y4fry47yhyd7', '', 'http://admin.theweavenest.com/uploads/product_image/1551335918.b3.jpg', 'dddd'),
(52, '18', 'linencotton', 'joifjiureijhivs', 800, 0, 'rgftrgtrggtrhgythszsdfref', '', 'http://admin.theweavenest.com/uploads/product_image/1551335998.b3.jpg', 'joifjiureijhivs'),
(53, '17', 'cottonnew', 'asdfff', 200, 100, 'vfvnjhoiuhjhjvo', '', 'http://admin.theweavenest.com/uploads/product_image/1551336257.h3.jpg', 'asdfff'),
(54, '17', 'cottonnew', 'frrddd', 500, 0, 'vgtrygtrdvgtr', '', 'http://admin.theweavenest.com/uploads/product_image/1551336289.h2.jpg', 'frrddd'),
(55, '16', 'banarasisilk', 'jkjbhk', 0, 0, 'nihuhuyu', '', 'http://admin.theweavenest.com/uploads/product_image/1551338584.h3.jpg', 'jkjbhk'),
(56, '18', 'linencotton', 'ssaaa', 2000, 1230, 'hwduuwhyuebfy7rgftcywgdxyieud', '', 'http://admin.theweavenest.com/uploads/product_image/1551351465.l1.jpg', 'ssaaa'),
(58, '17', 'cottonnew', 'gfggf', 50, 23, 'ftet5g5e3t4regt5ew', '', 'http://admin.theweavenest.com/uploads/product_image/1551419844.h2.jpg', 'gfggf'),
(60, '16', '14', 'demo', 400, 200, 'Assam silk denotes the three major types of indigenous wild silks produced in Assamâ€”golden muga, white pat and warm eri silk. The Assam silk industry', 'on', 'http://admin.theweavenest.com/uploads/product_image/1551871600.3.jpeg', 'demo'),
(64, '16', '14', 'decwasa', 600, 500, 'A Banarasi saree is a saree made in Varanasi, a city which is also called Benares or Banaras. The sarees are among the finest sarees in India and are known for their gold and silver brocade or zari,', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552038264.90D460__675_Kanjivaram-A_grande.jpg', 'decwasa'),
(65, '16', '14', 'dsas', 322, 22, 'fvefvcs', '', 'http://admin.theweavenest.com/uploads/product_image/1552037581.5.jpg', 'dsas'),
(66, '16', 'xyz', 'ghgbvf', 654, 54, 'hgfv', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552288293.0002445_traditional-soft-silk-saree.jpeg', 'ghgbvf'),
(67, '16', 'xyz', 'qasd', 123, 1, 'swd', 'on', 'http://admin.theweavenest.com/', 'qasd'),
(68, '16', 'xyz', 'asdf', 2345, 123, 'wsdef', 'on', 'http://admin.theweavenest.com/', 'asdf'),
(69, '16', 'xyz', 'asdf', 2345, 123, 'wsdef', 'on', 'http://admin.theweavenest.com/uploads/product_image/', 'asdf'),
(70, '16', 'xyz', 'asdf', 2345, 123, 'wsdef', 'on', 'http://admin.theweavenest.com/uploads/product_image/1552304110.jpg', 'asdf'),
(71, '18', 'linencotton', 'test', 10, 1, 'testing', '', 'http://admin.theweavenest.com/uploads/product_image/1552373710.46525729_307983896476443_6681608192058720256_n.jpg', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_review`
--

CREATE TABLE `tbl_review` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `Product` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_review`
--

INSERT INTO `tbl_review` (`id`, `name`, `email`, `message`, `Product`) VALUES
(1, 'saumya', 'puneetm65@gmail.com', 'wedefvgdergrthgtrg', 'aaaaaa'),
(2, 'Raghu', 'raghu@gmail.com', 'assdfdfghjkkiihyhhgg', 'ssaaa'),
(3, 'Mohit', 'puneetm65@gmail.com', 'gbdnjhmgxhjsg', 'gfggf'),
(4, 'Ajay', 'puneetm65@gmail.com', 'mjkiouioyfjyrfhdghbdgrsfs', 'frrddd'),
(5, 'Naveen', 'naveen@gmail.com', 'gvfthtfrhnynshsgserhbt', 'sdhju');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

CREATE TABLE `tbl_subcategory` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `subcategory` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`id`, `category`, `subcategory`) VALUES
(14, '17', 'cottonnew'),
(15, '18', 'linencotton'),
(17, '16', 'xyz');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_testimonials`
--

CREATE TABLE `tbl_testimonials` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `testimonials_image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_testimonials`
--

INSERT INTO `tbl_testimonials` (`id`, `user_name`, `feedback`, `created_at`, `testimonials_image`) VALUES
(7, 'xyz', 'xyz', '08-03-19', 'http://admin.theweavenest.com/uploads/testimonials_image/1552027620.41kkU2+62PL.jpg'),
(8, 'demo', 'demo', '08-03-19', 'http://admin.theweavenest.com/uploads/testimonials_image/1552027638.90D460__675_Kanjivaram-A_grande.jpg'),
(9, 'fds', 'rt', '08-03-19', 'http://admin.theweavenest.com/uploads/testimonials_image/1552027653.0002445_traditional-soft-silk-saree.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bagreview`
--
ALTER TABLE `tbl_bagreview`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bags`
--
ALTER TABLE `tbl_bags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bag_images`
--
ALTER TABLE `tbl_bag_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contactus`
--
ALTER TABLE `tbl_contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_image`
--
ALTER TABLE `tbl_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_review`
--
ALTER TABLE `tbl_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_testimonials`
--
ALTER TABLE `tbl_testimonials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_bagreview`
--
ALTER TABLE `tbl_bagreview`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_bags`
--
ALTER TABLE `tbl_bags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_bag_images`
--
ALTER TABLE `tbl_bag_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_contactus`
--
ALTER TABLE `tbl_contactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_image`
--
ALTER TABLE `tbl_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `tbl_review`
--
ALTER TABLE `tbl_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_testimonials`
--
ALTER TABLE `tbl_testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
